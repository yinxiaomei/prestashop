<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_8c4d7af5f578693f9a6cf391e912ee33'] = 'Вернулась пустая запись';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_f5c493141bb4b2508c5938fd9353291a'] = 'Показано %1$s из %2$s';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_12d3c7a4296542c62474856ec452c045'] = '№';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_49ee3087348e8d44e1feda1917443987'] = 'Имя';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_2a0440eec72540c5b30d9199c01f348c'] = 'Количество проданных';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6771f2d557a34bd89ea7abc92a0a069c'] = 'Цена продается';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Продажи';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_96e887520933606d3928a4ae164fe5e5'] = 'Количество проданных / день';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_7664a37e0cc56aaf39aebf2edbd3f98e'] = 'Просмотрено страниц';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6e71d214907cd43403f4bbde5731a9a3'] = 'Доступное количество для продажи';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_b9ef20f6c20406b631db52374a519b1f'] = 'Лучшие товары';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_dec6192cbc59ba37d38a3fdc5c3ed7f7'] = 'Список лучших товаров';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
