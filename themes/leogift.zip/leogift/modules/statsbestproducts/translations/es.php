<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_8c4d7af5f578693f9a6cf391e912ee33'] = 'Devolución de recordset vacío';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_f5c493141bb4b2508c5938fd9353291a'] = 'Mostrando %1$s de %2$s';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_12d3c7a4296542c62474856ec452c045'] = 'Ref.';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_2a0440eec72540c5b30d9199c01f348c'] = 'Cant.';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6771f2d557a34bd89ea7abc92a0a069c'] = 'Precio de venta';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'ventas';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_96e887520933606d3928a4ae164fe5e5'] = 'Cant./día';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_7664a37e0cc56aaf39aebf2edbd3f98e'] = 'Páginas vistas';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6e71d214907cd43403f4bbde5731a9a3'] = 'Cantidad disponible para la venta';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_b9ef20f6c20406b631db52374a519b1f'] = 'Mejores productos';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_dec6192cbc59ba37d38a3fdc5c3ed7f7'] = 'Lista de los mejores productos';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
