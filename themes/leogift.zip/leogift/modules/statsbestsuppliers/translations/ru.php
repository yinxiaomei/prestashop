<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_b5f5c19c8729b639d4d2a256fcb01a10'] = 'Вернулась пустая запись';
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_f5c493141bb4b2508c5938fd9353291a'] = 'Показано %1$s из %2$s';
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_49ee3087348e8d44e1feda1917443987'] = 'Название';
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_2a0440eec72540c5b30d9199c01f348c'] = 'Количество проданных';
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_ea067eb37801c5aab1a1c685eb97d601'] = 'Всего уделено';
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_cc3eb9ba7d0e236f33023a4744d0693a'] = 'Лучшие поставщики';
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_0fbee5f62b2695e84a5eb275bcf98c6f'] = 'Список лучших поставщиков';
$_MODULE['<{statsbestsuppliers}leogift>statsbestsuppliers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
