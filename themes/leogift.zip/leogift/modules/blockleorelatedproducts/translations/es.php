<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_876b62c6cff1d65b3465df83123be02f'] = 'Leo Productos relacionados Bloque';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_1666b78ee26e3234f03b1b0a6fe7fd49'] = 'Mostrar los productos en la misma categoría o relacionadas por género .... en el carrusel.';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizado';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_3c7679577cd1d0be2b98faf898cfc56d'] = 'Fecha de alta';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_235e70e4e7c0a3d61ccb6f60518ebd24'] = 'Fecha de alta DESC';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_1b7bb88b3317fe166424fa9e7535e1a9'] = 'Nombre DESC';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_694e8d1f2ee056f98ee488bdc4982d73'] = 'Cantidad';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_003085dd2a352e197d8efea06dfa75b8'] = 'Cantidad DESC';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_3601146c4e948c32b6424d2c0a7f0118'] = 'Precio';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_32da8a9347c34947b76a0a33d59edf4c'] = 'Precio DESC';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_b53787b5af6c89a0de9f1cf54fba9f21'] = 'El número máximo de productos en cada página del carrusel (por defecto: 3).';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_52a9719fc56cce0f0ea20673203c3ed7'] = 'Los productos de columna máximo en cada página del carrusel (por defecto: 3).';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_fc60123368f78620dcd75cde90aeec36'] = 'El número máximo de productos en cada carrusel (por defecto: 6).';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_4aae87211f77aada2c87907121576cfe'] = 'otros productos de la misma categoría:';
$_MODULE['<{blockleorelatedproducts}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuevo';
$_MODULE['<{blockleorelatedproducts}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Más';
$_MODULE['<{blockleorelatedproducts}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{blockleorelatedproducts}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir a cesta';
