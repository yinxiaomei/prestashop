<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}leogift>statsequipment_719d067b229178f03bcfa1da4ac4dede'] = 'Software';
$_MODULE['<{statsequipment}leogift>statsequipment_236d6d0b5cc4428f346c235e0c60faaa'] = 'Mostrar el Software utilizado por sus visitantes';
$_MODULE['<{statsequipment}leogift>statsequipment_d36312e9992d0b03780a32fedd6650b7'] = 'Determine la repartición de los buscadores que utilizan sus clientes';
$_MODULE['<{statsequipment}leogift>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
$_MODULE['<{statsequipment}leogift>statsequipment_c560add3373d03ea2723069fb428719a'] = 'Determine la repartición de los sistemas operativo que utilizan sus clientes';
$_MODULE['<{statsequipment}leogift>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Plug-ins';
$_MODULE['<{statsequipment}leogift>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{statsequipment}leogift>statsequipment_501361472d0528ee07f202297f599d40'] = 'Asegúrese de que su sitio Web sea accesible a todos';
$_MODULE['<{statsequipment}leogift>statsequipment_ef83f5147398f2735fddfaac983983d7'] = 'Buscador utilizado';
$_MODULE['<{statsequipment}leogift>statsequipment_0a66f998cfad4890a14c9b9a1df8deb3'] = 'Sistema operativo utilizado';
