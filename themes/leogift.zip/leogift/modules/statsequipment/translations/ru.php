<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}leogift>statsequipment_719d067b229178f03bcfa1da4ac4dede'] = 'Програмное обеспечение';
$_MODULE['<{statsequipment}leogift>statsequipment_236d6d0b5cc4428f346c235e0c60faaa'] = 'Показать программного обеспечения, используемое посетителями сайта.';
$_MODULE['<{statsequipment}leogift>statsequipment_d36312e9992d0b03780a32fedd6650b7'] = 'Определить процент веб-браузеров используемых вашими клиентами.';
$_MODULE['<{statsequipment}leogift>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsequipment}leogift>statsequipment_c560add3373d03ea2723069fb428719a'] = 'Определить процент операционных систем, используемых вашими клиентами.';
$_MODULE['<{statsequipment}leogift>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Плагины';
$_MODULE['<{statsequipment}leogift>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsequipment}leogift>statsequipment_501361472d0528ee07f202297f599d40'] = 'Убедитесь, что ваш сайт доступен для всех.';
$_MODULE['<{statsequipment}leogift>statsequipment_ef83f5147398f2735fddfaac983983d7'] = 'Используемый браузер';
$_MODULE['<{statsequipment}leogift>statsequipment_0a66f998cfad4890a14c9b9a1df8deb3'] = 'Операционная система';
