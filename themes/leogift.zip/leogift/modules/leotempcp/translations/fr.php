<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leotempcp}leogift>leotempcp_2e976d1052649efb14292f3b0a0a7230'] = 'Panneau de configuration du thème Leo	';
$_MODULE['<{leotempcp}leogift>leotempcp_f0829f0a745a34bff7565504856489ca'] = 'changer la couleur de thème	';
$_MODULE['<{leotempcp}leogift>leotempcp_cb66b72c67288bba55c6b62fb58f59df'] = 'Etes-vous sûr que vous voulez désinstaller Skins thème?	';
$_MODULE['<{leotempcp}leogift>leotempcp_207c321933d5e7273bf3defb9eca01af'] = 'Verdana	';
$_MODULE['<{leotempcp}leogift>leotempcp_eada819634d0164c6a7547bdcc405033'] = 'Géorgie	';
$_MODULE['<{leotempcp}leogift>leotempcp_6fbda3a3567da6d01bc9da915e91d702'] = 'Arial	';
$_MODULE['<{leotempcp}leogift>leotempcp_21f59b54f62b5b8b4bc0f63f0f617fc1'] = 'Incidence	';
$_MODULE['<{leotempcp}leogift>leotempcp_2bd141ae2a8e92e3cdd9163089ec8924'] = 'Tahoma	';
$_MODULE['<{leotempcp}leogift>leotempcp_720661ecef8eaa75b0d48a938bff3404'] = 'Trebuchet MS	';
$_MODULE['<{leotempcp}leogift>leotempcp_94a7bb970f9da770117889c237284e75'] = 'Arial Black	';
$_MODULE['<{leotempcp}leogift>adminleotempcppanel_4086d76c2e708560934b203aed9c9662'] = 'Enregistrer positions	';
$_MODULE['<{leotempcp}leogift>adminleotempcppanel_b0301033a440844d134fcfa7b3ffb792'] = 'Panneau de configuration de thème	';
$_MODULE['<{leotempcp}leogift>adminleotempcppanel_82fb0558ff2af9bdae555235bc4eb364'] = 'Live Edit	';
$_MODULE['<{leotempcp}leogift>adminleotempcppanel_6a26f548831e6a8c26bfbbd9f6ec61e0'] = 'Aide	';
$_MODULE['<{leotempcp}leogift>panel_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
