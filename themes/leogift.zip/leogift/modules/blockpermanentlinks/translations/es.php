<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-footer_5813ce0ec7196c492c97596718f71969'] = 'mapa del sitio';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-footer_bbaff12800505b22a853e8b7f4eb6a22'] = 'contacto';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-footer_714814d37531916c293a8a4007e8418c'] = 'añada esta página a favoritos';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contacto';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'mapa del sitio';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_fad9383ed4698856ed467fd49ecf4820'] = 'Favoritos';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_39355c36cfd8f1d048a1f84803963534'] = 'Bloque de enlaces permanentes';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_52ecdc5932442c5f2a22ade561140870'] = 'Añadir un bloque que muestre los enlaces permanentes como mapa del sitio, contacto, etc.';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_5813ce0ec7196c492c97596718f71969'] = 'mapa del sitio';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_bbaff12800505b22a853e8b7f4eb6a22'] = 'contacto';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_2d29fbe96aaeb9737b355192f4683690'] = 'añada esta página a favoritos';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_2cbfb6731610056e1d0aaacde07096c1'] = 'Ver mi cuenta';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_83218ac34c1834c26781fe4bde918ee4'] = 'Bienvenida';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Mi cuenta';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_641254d77e7a473aa5910574f3f9453c'] = 'Lista De';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_6ff063fbc860a79759a7369ac32cee22'] = 'Pedido';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_4b877ba8588b19f1b278510bf2b57ebb'] = 'Desconectarme';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_4394c8d8e63c470de62ced3ae85de5ae'] = 'Desconectar';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_b145abfd6b2f88971d725cbd94a5879f'] = 'Ingrese a su cuenta de cliente';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_99dea78007133396a7b8ed70578ac6ae'] = 'Ingresa';
