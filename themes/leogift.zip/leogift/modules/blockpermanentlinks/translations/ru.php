<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-footer_5813ce0ec7196c492c97596718f71969'] = 'карта сайта';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-footer_bbaff12800505b22a853e8b7f4eb6a22'] = 'контакты';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-footer_714814d37531916c293a8a4007e8418c'] = 'добавить страницу в закладки';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'Контакты';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'Карта сайта';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_fad9383ed4698856ed467fd49ecf4820'] = 'в закладки';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_39355c36cfd8f1d048a1f84803963534'] = 'Блок постоянных ссылок';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_52ecdc5932442c5f2a22ade561140870'] = 'Добавляет блок, отображающий постоянные ссылки, например - контакты, карта сайта и т.п.';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_5813ce0ec7196c492c97596718f71969'] = 'карта сайта';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_bbaff12800505b22a853e8b7f4eb6a22'] = 'контакты';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks_2d29fbe96aaeb9737b355192f4683690'] = 'добавить страницу в закладки';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_2cbfb6731610056e1d0aaacde07096c1'] = 'Посмотреть мои счета клиента';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_83218ac34c1834c26781fe4bde918ee4'] = 'добро пожаловать';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Моя учетная запись';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_641254d77e7a473aa5910574f3f9453c'] = 'Список желаний';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_6ff063fbc860a79759a7369ac32cee22'] = 'контроль';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_4b877ba8588b19f1b278510bf2b57ebb'] = 'Выйду';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_4394c8d8e63c470de62ced3ae85de5ae'] = 'Выйти';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_b145abfd6b2f88971d725cbd94a5879f'] = 'Вход в вашей учетной записи клиента';
$_MODULE['<{blockpermanentlinks}leogift>blockpermanentlinks-header_99dea78007133396a7b8ed70578ac6ae'] = 'Войти';
