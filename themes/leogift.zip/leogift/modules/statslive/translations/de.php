<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statslive}leogift>statslive_fa55230e9791f2b71322869318a5f00f'] = 'Besucher online';
$_MODULE['<{statslive}leogift>statslive_b8a5ea9b6e7f2d0b56fbb18e5b6b9246'] = 'Zeigt eine Liste der Kunden und Besucher, die zur Zeit online sind';
$_MODULE['<{statslive}leogift>statslive_e6214c05e17c56f81e4a56f4c4fdce8c'] = 'Sie müssen die Option \"Seitenaufrufe für jeden Kunden\" im \"statistische Datenerhebung\"-Modul aktivieren, um die aktuell von Kunden besuchten Seiten zu sehen.';
$_MODULE['<{statslive}leogift>statslive_5c948349bdf1a7a77ba54497d019e4ca'] = 'Kunden online';
$_MODULE['<{statslive}leogift>statslive_66c4c5112f455a19afde47829df363fa'] = 'Gesamt:';
$_MODULE['<{statslive}leogift>statslive_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statslive}leogift>statslive_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{statslive}leogift>statslive_f88589c3e803217e3f6fe9d8e740e6e8'] = 'Aktuelle Seite';
$_MODULE['<{statslive}leogift>statslive_4351cfebe4b61d8aa5efa1d020710005'] = 'Anzeigen';
$_MODULE['<{statslive}leogift>statslive_4ce4b5e9a6a3e91ac46dec882a36e0db'] = 'Aktuell keine Kunden online.';
$_MODULE['<{statslive}leogift>statslive_adb831a7fdd83dd1e2a309ce7591dff8'] = 'Gast';
$_MODULE['<{statslive}leogift>statslive_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{statslive}leogift>statslive_38c50b731f70abc42c8baa3e7399b413'] = 'Seit';
$_MODULE['<{statslive}leogift>statslive_13aa8652e950bb7c4b9b213e6d8d0dc5'] = 'Aktuelle Seite';
$_MODULE['<{statslive}leogift>statslive_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referrer';
$_MODULE['<{statslive}leogift>statslive_ec0fc0100c4fc1ce4eea230c3dc10360'] = 'Keine Angabe';
$_MODULE['<{statslive}leogift>statslive_6adf97f83acf6453d4a6a4b1070f3754'] = 'Nichts';
$_MODULE['<{statslive}leogift>statslive_a55533db46597bee3cd16899c007257e'] = 'Zur Zeit sind keine Besucher online.';
