<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphxmlswfcharts}leogift>graphxmlswfcharts_fd1d6df8df2837bc1690e3ca9d84f502'] = 'Listy XML / SWF';
$_MODULE['<{graphxmlswfcharts}leogift>graphxmlswfcharts_723f92861aa774c9d255e0b8c42c29e8'] = 'Listy XML / SWF jest to proste, ale potężne narzędzie które przy użyciu programu Adobe Flash pozwala stworzyć atrakcyjne web wykresy i wykresy z dynamicznych danych.';
