<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscatalog}leogift>statscatalog_cf3aa21c6a2147ddbd86f34091daeccd'] = 'Statystyki katalogu';
$_MODULE['<{statscatalog}leogift>statscatalog_226ed1224c5b2db3d3e0716bb4f74da5'] = 'Ogólne statystyki Twojego katalogu';
$_MODULE['<{statscatalog}leogift>statscatalog_74cda5a02df704cc5c3e8fee7fc0f7bc'] = '(1 zakup / %d wizyt)';
$_MODULE['<{statscatalog}leogift>statscatalog_0173374ac20f5843d58b553d5b226ef6'] = 'Wybierz kategorię';
$_MODULE['<{statscatalog}leogift>statscatalog_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Wszystkie';
$_MODULE['<{statscatalog}leogift>statscatalog_a7b623414d4b6a3225b4e935babec6d2'] = 'Produkty dostępne:';
$_MODULE['<{statscatalog}leogift>statscatalog_1099377f1598a0856e2457a5145d89c2'] = 'Średnia cena (cena bazowa):';
$_MODULE['<{statscatalog}leogift>statscatalog_48a93dc02c74f3065af1ba47fca070d0'] = 'Wyświetlono stron produktu:';
$_MODULE['<{statscatalog}leogift>statscatalog_156e5c5872c9af24a5c982da07a883c2'] = 'Produkty kupione:';
$_MODULE['<{statscatalog}leogift>statscatalog_85f179d4142ca061d49605a7fffdc09d'] = 'Średnia liczba oglądanych stron:';
$_MODULE['<{statscatalog}leogift>statscatalog_05ff4bfc3baf0acd31a72f1ac754de04'] = 'Średnia liczba zakupów:';
$_MODULE['<{statscatalog}leogift>statscatalog_c09d09e371989d89847049c9574b6b8e'] = 'Ilość dostępnych zdjęć:';
$_MODULE['<{statscatalog}leogift>statscatalog_65275d1b04037d8c8e42425002110363'] = 'Średnia liczba zdjęć:';
$_MODULE['<{statscatalog}leogift>statscatalog_51b8891d531ad91128ba58c8928322ab'] = 'Produkty nigdy nie oglądane:';
$_MODULE['<{statscatalog}leogift>statscatalog_8725647ef741e5d48c1e6f652ce80b50'] = 'Produkty nigdy nie kupione:';
$_MODULE['<{statscatalog}leogift>statscatalog_b86770bc713186bcf43dbb1164c5fd28'] = 'Stopa konwersji*:';
$_MODULE['<{statscatalog}leogift>statscatalog_0468e0edbf9f5807c25c106248bd7401'] = 'Średnia konwersji strony produktu. Istnieje możliwość zakupu produktu bez wyświetlania strony produktu, a więc stopa ta może być większa niż 1.';
$_MODULE['<{statscatalog}leogift>statscatalog_58a714d3e9bb2902a5b688c99bd4d8e6'] = 'Produkty nigdy nie kupione.';
$_MODULE['<{statscatalog}leogift>statscatalog_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statscatalog}leogift>statscatalog_49ee3087348e8d44e1feda1917443987'] = 'Nazwa';
$_MODULE['<{statscatalog}leogift>statscatalog_8e7c9a35104a5a68199678bd6bc5d187'] = 'Edycja / Wyświetl';
