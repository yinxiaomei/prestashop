<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sendtoafriend}leogift>product_page_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'An einen Freund senden';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_d1f092e79827eaffce4a33fa011fde24'] = 'Bitte füllen Sie alle Pflichtfelder aus';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'An einen Freund senden';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_5d6103b662f41b07e10687f03aca8fdc'] = 'Empfänger';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_bb6aa0be8236a10e6d3b315ebd5f2547'] = 'Name Ihrer/es Freundin/es';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_099bc8914b5be9e522a29e48cb3c01c4'] = 'E-Mailadresse Ihres Freundes';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_70397c4b252a5168c5ec003931cea215'] = 'Pflichtfelder';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_ea4788705e6873b424c65e91c2846b19'] = 'Abbrechen';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_e81c4e4f2b7b93b481e13a8553c2ae1b'] = 'oder';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend-extra_94966d90747b97d1f0f206c98a8b1ac3'] = 'Senden';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_2074615eb70699e55b1f9289c6c77c25'] = 'An einen Freund senden-Modul';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_3234e2609dd694d8763c390fe97eba04'] = 'Ermöglicht den Kunden, einen Produktlink an einen Freund zu senden';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'An einen Freund senden';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_20589174124c25654cac3736e737d2a3'] = 'Senden Sie diese Seite einem Freund, der an diesem Artiekl interessiert sein könnte.';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_b31afdfa73c89b567778f15180c2dd6c'] = 'Ihre Email wurde erfolgreich versendet';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_e55de03786f359e2b133f2a74612eba6'] = 'Name des Freundes:';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_19f41c3d6db934fb2db1840ddefd2c51'] = 'E-Mail des Freundes:';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_2541d938b0a58946090d7abdde0d3890'] = 'senden';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_68728c1897e5936032fe21ffb6b10c2e'] = 'Zurück zur Produktseite';
$_MODULE['<{sendtoafriend}leogift>sendtoafriend_ajax_22c4733a9ceb239bf825a0cecd1cfaec'] = 'Ein Freund';
