<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Aucun résultat retourné';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'Показано %1$s из %2$s';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Фамилия';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Имя';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'Argent dépensé';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Meilleurs clients';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_ca5c7eec61c59f2bd4572d1c5f34b10a'] = 'Спиок лучших покупателей';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Fidéliser les clients';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_0c854a411bcae590a2a44a9b18487d12'] = 'Удержание клиента выгоднее, чем получение нового. Таким образом, необходимо развивать лояльность, чтобы они захотели вернуться в ваш интернет-магазин.';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'Сарафанное радио - также средство для получения новых, удовлетворенных клиентов; недовольный клиент не посоветует вас друзьям.';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_860b64638db92a2d084e4e5182b20f31'] = 'Для того, чтобы достичь этого, вы можете использовать:';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_99666939cbe5b9f120bb5a5050abda66'] = 'Эти операции поощряют клиентов покупать товары и регулярно посещать ваш магазин.';
