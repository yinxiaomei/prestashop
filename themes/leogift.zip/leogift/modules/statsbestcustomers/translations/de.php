<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Leerer Datensatz zurückgegeben';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = '%1$s von %2$s';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Nachname';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Vorname';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-Mail';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Besuche';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'ausgegebenes Geld';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Beste Kunden';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_ca5c7eec61c59f2bd4572d1c5f34b10a'] = 'Übersicht der besten Kunden';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Kundentreue entwickeln';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_0c854a411bcae590a2a44a9b18487d12'] = 'Einen Kunden zu behalten ist rentabler als einen Neukunden zu akquirieren. Daher ist es notwendig, Ihre Treue zu gewinnen, oder anders gesagt, sie dazu zu bringen, zu Ihrem Webshop zurückzukehren.';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'Mundpropaganda ist ebenfalls ein Mittel, um neue,zufriedene Kunden zu bekommen; ein unzufriedener Kunde zieht keine Neukunden an.';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_860b64638db92a2d084e4e5182b20f31'] = 'Um dieses Ziel zu erreichen, können Sie Folgendes machen:';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_99666939cbe5b9f120bb5a5050abda66'] = 'Solche Aktionen animieren Kunden, Produkte zu kaufen und Ihren Webshop regelmäßig zu besuchen.';
