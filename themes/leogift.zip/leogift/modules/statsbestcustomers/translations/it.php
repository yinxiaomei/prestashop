<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Recordset vuoto restituito';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'Mostra %1$s di %2$s';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Cognome';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Nome';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Visite';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'Denaro speso';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Migliori clienti';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_ca5c7eec61c59f2bd4572d1c5f34b10a'] = 'Elenco dei migliori clienti.';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'Esporta CSV';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Sviluppa la fedeltà dei clienti';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_0c854a411bcae590a2a44a9b18487d12'] = 'Mantenere un cliente è più redditizio che catturarne uno nuovo. Pertanto, è necessario sviluppare la loro fedeltà, in altre parole, devi farli tornare al tuo negozio online.';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'Il passaparola è anche un mezzo per ottenere nuovi clienti soddisfatti; un cliente non soddisfatto non attirerà nuovi clienti.';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_860b64638db92a2d084e4e5182b20f31'] = 'Al fine di raggiungere questo obiettivo è possibile organizzare:';
$_MODULE['<{statsbestcustomers}leogift>statsbestcustomers_99666939cbe5b9f120bb5a5050abda66'] = 'Queste operazioni incoraggiare i clienti ad acquistare prodotti e visitare il vostro negozio online regolarmente.';
