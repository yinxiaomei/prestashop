<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}leogift>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Поиск:';
$_MODULE['<{blocksearch}leogift>blocksearch_e2ca130372651672ba285abd796412ed'] = 'Блок быстрого поиска';
$_MODULE['<{blocksearch}leogift>blocksearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Добавляет блок с полем быстрого поиска.';
$_MODULE['<{blocksearch}leogift>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Поиск';
$_MODULE['<{blocksearch}leogift>blocksearch_3d4999b5a4129d6c189f50d6f977b846'] = 'Укажите название товара';
$_MODULE['<{blocksearch}leogift>blocksearch_1fb103afe92d693ae23d0463b185a9a7'] = 'перейти';
$_MODULE['<{blocksearch}leogift>blocksearch_52d578d063d6101bbdae388ece037e60'] = 'Введите название товара';
$_MODULE['<{blocksearch}leogift>blocksearch_34d1f91fb2e514b8576fab1a75a89a6b'] = 'Искать';
