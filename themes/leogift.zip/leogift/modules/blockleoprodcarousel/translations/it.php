<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_0464a3a8e8a79cb31698239b8a57d207'] = 'Il numero massimo di prodotti in ogni pagina Carousel (default: 4).';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_b53787b5af6c89a0de9f1cf54fba9f21'] = 'Il numero massimo di prodotti in ogni pagina Carousel (default: 3).';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_52a9719fc56cce0f0ea20673203c3ed7'] = 'I prodotti della colonna massimi in ogni pagina Carousel (default: 3).';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_dd69d9ed74c15ee11411c2e561234324'] = 'Il numero massimo di prodotti in ogni Carousel (default: 12).';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_db5bbee0cb649caceaa88f704351ac80'] = 'Ultimi Prodotti';
$_MODULE['<{blockleoprodcarousel}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Sì';
$_MODULE['<{blockleoprodcarousel}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nessun';
$_MODULE['<{blockleoprodcarousel}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuovo';
$_MODULE['<{blockleoprodcarousel}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Maggiori';
$_MODULE['<{blockleoprodcarousel}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizza';
$_MODULE['<{blockleoprodcarousel}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aggiungi al carrello';
