<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_36183891b6ad0395ebc28201267ff843'] = 'Leo produits Carousel Bloquer	';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_2a96ef70e47122f45b14250d76646dd5'] = 'Afficher les produits des catégories dans le carrousel.	';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour	';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_3c7679577cd1d0be2b98faf898cfc56d'] = 'Date d\'insertion	';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_b53787b5af6c89a0de9f1cf54fba9f21'] = 'Le nombre maximum de produits dans chaque page Carousel (par défaut: 3).';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_52a9719fc56cce0f0ea20673203c3ed7'] = 'Les produits de colonnes maximum dans chaque page Carousel (par défaut: 3).';
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockleoprodcarousel}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Qui';
$_MODULE['<{blockleoprodcarousel}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{blockleoprodcarousel}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_MODULE['<{blockleoprodcarousel}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{blockleoprodcarousel}leogift>products_2d96bb66d8541a89620d3c158ceef42b'] = 'Ajouter à mes favoris	';
$_MODULE['<{blockleoprodcarousel}leogift>products_723edf7c24638ed18d2fa831e647a5cc'] = 'liste	';
$_MODULE['<{blockleoprodcarousel}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Voir';
$_MODULE['<{blockleoprodcarousel}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Plus';
