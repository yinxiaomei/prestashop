<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leobootstrapmenu}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Qui';
$_MODULE['<{leobootstrapmenu}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
