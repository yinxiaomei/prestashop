<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sekeywords}leogift>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Parole chiave dei motori di ricerca';
$_MODULE['<{sekeywords}leogift>sekeywords_de13be6263895a5efe4d51e15ab1535e'] = 'Visualizza le parole chiave che hanno portato i visitatori del tuo sito web.';
$_MODULE['<{sekeywords}leogift>sekeywords_16d5f8dc3bc4411c85848ae9cf6a947a'] = 'La parola chiave %d corrisponde alla tua ricerca.';
$_MODULE['<{sekeywords}leogift>sekeywords_5029f8eef402bb8ddd6191dffb5e7c19'] = 'La parola chiave %d corrisponde alla tua ricerca.';
$_MODULE['<{sekeywords}leogift>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Parole chiave';
$_MODULE['<{sekeywords}leogift>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Occorrenze';
$_MODULE['<{sekeywords}leogift>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'Esporta CSV';
$_MODULE['<{sekeywords}leogift>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filtra per parole chiave';
$_MODULE['<{sekeywords}leogift>sekeywords_6e632566b6e16dbd2273e83d7c53182b'] = 'E occorrenze min';
$_MODULE['<{sekeywords}leogift>sekeywords_fa73b7cd0d2681f6d871c9ef4023ad39'] = 'Applica';
$_MODULE['<{sekeywords}leogift>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'Nessuna parola chiave';
$_MODULE['<{sekeywords}leogift>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{sekeywords}leogift>sekeywords_9ed50bd6876a9273f2192c224b87657b'] = 'Identifica parole chiave motori di ricerca estenri';
$_MODULE['<{sekeywords}leogift>sekeywords_6534eadba477de8a632ff59ac20b572f'] = 'Uno dei modi più comuni di trovare un sito web attraverso un motore di ricerca.';
$_MODULE['<{sekeywords}leogift>sekeywords_0d7ce5d105706cedba41887d3f1c0ea1'] = 'Identificare le parole chiave più popolari inseriti dai vostri nuovi visitatori ti permette di vedere quali prodotti si dovrebbe mettere in evidenza, se si vuole attirare più visitatori e potenziali clienti.';
$_MODULE['<{sekeywords}leogift>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = 'Come funziona?';
$_MODULE['<{sekeywords}leogift>sekeywords_722e091cccbd9a9ec8f4a35bf1f35893'] = 'Quando un visitatore arriva al tuo sito web, il server registra la loro posizione precedente. Questo modulo analizza l\'URL e trova le parole chiave in essa.';
$_MODULE['<{sekeywords}leogift>sekeywords_d8b08c48a8d8e739399594adec89458a'] = 'Attualmente, gestisce i seguenti motori di ricerca: %1$s e %2$s.';
$_MODULE['<{sekeywords}leogift>sekeywords_50dca930b804e845a852512b44d51c52'] = 'Presto sarà possibile aggiungere dinamicamente un nuovo motore di ricerca e contribuire a questo modulo.';
$_MODULE['<{sekeywords}leogift>sekeywords_e15832aa200f342e8f4ab580b43a72a8'] = 'Le prime 10 parole chiave';
$_MODULE['<{sekeywords}leogift>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Altri';
