<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sekeywords}leogift>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Mots-clés';
$_MODULE['<{sekeywords}leogift>sekeywords_de13be6263895a5efe4d51e15ab1535e'] = 'Affiche les mots-clés qui ont mené les visiteurs jusqu\'à votre boutique.';
$_MODULE['<{sekeywords}leogift>sekeywords_16d5f8dc3bc4411c85848ae9cf6a947a'] = '%d mot-clé trouvé pour votre recherche.';
$_MODULE['<{sekeywords}leogift>sekeywords_5029f8eef402bb8ddd6191dffb5e7c19'] = '%d mots-clés trouvés pour votre recherche.';
$_MODULE['<{sekeywords}leogift>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Mots-clés';
$_MODULE['<{sekeywords}leogift>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Occurences';
$_MODULE['<{sekeywords}leogift>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{sekeywords}leogift>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Filter par mot-clé';
$_MODULE['<{sekeywords}leogift>sekeywords_6e632566b6e16dbd2273e83d7c53182b'] = 'et minimum d\'occurrences';
$_MODULE['<{sekeywords}leogift>sekeywords_fa73b7cd0d2681f6d871c9ef4023ad39'] = 'Appliquer';
$_MODULE['<{sekeywords}leogift>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'Aucun mot-clé';
$_MODULE['<{sekeywords}leogift>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{sekeywords}leogift>sekeywords_9ed50bd6876a9273f2192c224b87657b'] = 'Identifier les mots-clés par moteurs de recherche externes';
$_MODULE['<{sekeywords}leogift>sekeywords_6534eadba477de8a632ff59ac20b572f'] = 'Une des façons les plus courantes de trouver un site web grâce à un moteur de recherche.';
$_MODULE['<{sekeywords}leogift>sekeywords_0d7ce5d105706cedba41887d3f1c0ea1'] = 'Identifier les mots clés les plus populaires saisies par vos nouveaux visiteurs vous permet de voir quels produits vous devriez mettre en avant si vous voulez attirer plus de visiteurs et clients potentiels.';
$_MODULE['<{sekeywords}leogift>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = 'Comment ça marche ?';
$_MODULE['<{sekeywords}leogift>sekeywords_722e091cccbd9a9ec8f4a35bf1f35893'] = 'Quand un visiteur vient sur votre site web, le serveur récupère leur emplacement précédent. Ce module analyse l\'URL et trouve les mots-clés en elle.';
$_MODULE['<{sekeywords}leogift>sekeywords_d8b08c48a8d8e739399594adec89458a'] = 'Actuellement, il gère les moteurs de recherche suivants: %1$s et %2$s.';
$_MODULE['<{sekeywords}leogift>sekeywords_50dca930b804e845a852512b44d51c52'] = 'Bientôt il sera possible d\'ajouter dynamiquement de nouveaux moteurs de recherche à cette liste, et ainsi contribuer au développement du module !';
$_MODULE['<{sekeywords}leogift>sekeywords_e15832aa200f342e8f4ab580b43a72a8'] = '10 premiers mots-clés';
$_MODULE['<{sekeywords}leogift>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Autres';
