<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_6e67afa558eac4a182defab0884d1abf'] = 'Leo Producto Tabs Bloquear';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_c2fb79a6eca86e519f938a1ef15c3e69'] = 'Agrega un bloque con ofertas especiales de productos.';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizado';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_f44441b45f4e8dc7f75e9470a01952f9'] = 'Número de elementos en la página';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_eec0b0d9e243d2b626d7732f759ce46b'] = 'El número máximo de productos en cada ficha de la página (por defecto: 3).';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_e46be59191719d6eebf547872e26761f'] = 'Número de columnas de la página';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_7e29bc2364b066b48ee49bd7248acf82'] = 'Cantidad de productos exhibidos en Tab';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_a0cdf62595a825674ce3dc2ddbc12609'] = 'El número máximo de productos en cada ficha (por defecto: 6).';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_d34cd7cbbcd8d3296363084859d32597'] = 'Tab Especial';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_a8a670d89a6d2f3fa59942fc591011ef'] = 'Mostrar el bloque de incluso si no hay producto está disponible.';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_2891e6bd1b6e8b4be99a6941ff6f1ff0'] = 'Mejor Tab Vendedor';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_aaffcd9ede4a83ea0678e1f8acb0f8bb'] = 'Tab destacados';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_a93f0744f60adc61871989817f039d95'] = 'Nueva Arrials Tab';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_b4c2b550635fe54fd29f2b64dfaca55d'] = 'Especial';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_31d26a6487e08357bd771619e894b0c6'] = 'Nuevas adquisiciones';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_22c6735b370cecf293e32dca6c678185'] = 'El superventas';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_cf8156f1f57a8603cd6b3a28c9c2c61b'] = 'Productos destacados';
$_MODULE['<{blockleoproducttabs}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuevo';
$_MODULE['<{blockleoproducttabs}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Más';
$_MODULE['<{blockleoproducttabs}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Ver';
$_MODULE['<{blockleoproducttabs}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Añadir a cesta';
