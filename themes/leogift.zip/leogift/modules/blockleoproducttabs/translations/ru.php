<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_6e67afa558eac4a182defab0884d1abf'] = 'Лев продукта Вкладки Блока';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_c2fb79a6eca86e519f938a1ef15c3e69'] = 'Добавляет блок с текущего экстренного продукта.';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновленной';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_f4f70727dc34561dfde1a3c529b6205c'] = 'настройки';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_f44441b45f4e8dc7f75e9470a01952f9'] = 'Количество элементов в Page';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_eec0b0d9e243d2b626d7732f759ce46b'] = 'Максимальное количество товаров в каждой закладке (по умолчанию: 3).';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_e46be59191719d6eebf547872e26761f'] = 'Количество столбцов в страницу';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_7e29bc2364b066b48ee49bd7248acf82'] = 'Количество продуктов отображается на вкладке';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_a0cdf62595a825674ce3dc2ddbc12609'] = 'Максимальное количество товаров в каждой вкладки (по умолчанию: 6).';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_d34cd7cbbcd8d3296363084859d32597'] = 'специальная вкладка';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_b9f5c797ebbf55adccdd8539a65a0241'] = 'инвалид';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_a8a670d89a6d2f3fa59942fc591011ef'] = 'Показать блока, даже если нет продукта доступны.';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_2891e6bd1b6e8b4be99a6941ff6f1ff0'] = 'Бестселлер Tab';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_aaffcd9ede4a83ea0678e1f8acb0f8bb'] = 'Рекомендуемые Tab';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_a93f0744f60adc61871989817f039d95'] = 'Новый Arrials Tab';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_c9cc8cce247e49bae79f15173ce97354'] = 'экономить';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_b4c2b550635fe54fd29f2b64dfaca55d'] = 'специальный';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_31d26a6487e08357bd771619e894b0c6'] = 'Новые поступления';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_22c6735b370cecf293e32dca6c678185'] = 'Бестселлеры';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_cf8156f1f57a8603cd6b3a28c9c2c61b'] = 'Рекомендуемые товары';
$_MODULE['<{blockleoproducttabs}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'новое';
$_MODULE['<{blockleoproducttabs}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'больше';
$_MODULE['<{blockleoproducttabs}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'смотреть';
$_MODULE['<{blockleoproducttabs}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Добавить в корзину';
