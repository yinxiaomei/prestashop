<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Página no encontrada';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_220b13b2c5c94e16c5895e3925270617'] = 'Mostrar las páginas solicitadas por sus visitantes pero no encontradas';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_da4c19289501755f54f1a9223d0271cc'] = 'Páginas no encontradas suprimidas';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_23dbe39a97cb7e4e528f25f5795d317f'] = 'Las páginas no encontradas se han actualizado';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6b4cd0cb089425011df02c8e86a1b832'] = 'Usted debe utilizar un archivo .htaccess para volver a redirigir error 404 al de la página';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Página';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referente';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contador';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Páginas no registradas';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Suprimir';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_4613b06701504f4a6664effb977b3e32'] = 'Suprimir TODAS las páginas no encontradas en este periodo';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'Suprimir TODAS las páginas no encontradas';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'error 404';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_a90083861c168ef985bf70763980aa60'] = '¿Como prevenir estos errores?';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_f0698625adc9935b9a8d40eb128922c2'] = 'Si su servidor soporta el archivo .htaccess, puede crear uno en el directorio raíz de PrestaShop e insertar la línea siguiente:';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_54c5be2cbf4d4a829069fd28903507b0'] = 'El usuario que busca una página que no existe será reenviado a la página';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_499066312cb6ca89c060f67dcad7c7a6'] = 'Este módulo registra los accesos a esta página: la página requerida, la referencia y el número de veces que se visitó.';
