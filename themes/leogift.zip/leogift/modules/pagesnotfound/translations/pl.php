<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Strony nie znaleziono';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_220b13b2c5c94e16c5895e3925270617'] = 'Wyświetl strony wywoływane przez odwiedzających, ale nie odnalezione.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_da4c19289501755f54f1a9223d0271cc'] = 'Strony nie znaleziono został opróżniony.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_23dbe39a97cb7e4e528f25f5795d317f'] = 'Strony nie odnalezione zostały usunięte.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6b4cd0cb089425011df02c8e86a1b832'] = 'Musisz użyć .htaccess plik, aby przekierować 404 błędy na stronę \"404.php\"';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Strona';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Odnośnik';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Licznik';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Brak zarejestrowanych stron';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Pusta baza danych';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_4613b06701504f4a6664effb977b3e32'] = 'Opróżnij WSZYSTKIE nie odnalezione strony w tym okresie';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'Opróżnij WSZYSTKIE nie odnalezione strony';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'Błedy 404';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Jak przechwytywać te błędy?';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_f0698625adc9935b9a8d40eb128922c2'] = 'Jeśli webhost wspiera plik .htaccess, możesz go utworzyć w katalogu głównym PrestaShop i wstawić następujący wiersz wewnątrz:';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_54c5be2cbf4d4a829069fd28903507b0'] = 'Żądanie wyświetlenia strony użytkownika, która nie istnieje, zostanie przekierowane do tej strony.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_499066312cb6ca89c060f67dcad7c7a6'] = 'Moduł ten rejestruje dostęp do tej strony: żądania strony, odnośnik i czas kiedy to nastąpiło.';
