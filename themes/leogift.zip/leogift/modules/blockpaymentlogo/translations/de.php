<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_ea2d4e3948f9543e5939efd1663ddef5'] = 'Block Zahlungslogo';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_d272c8b17089521db4660c7852f8839c'] = 'Fügt einen Block mit allen Zahlungslogos hinzu';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_fb0c64625321a2f2e5e8800a7ddbd759'] = 'Zahlungslogo';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Einstellungen werden aktualisiert';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Keine CMS-Seite verfügbar';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Konfigurieren';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_4b3c34d991275b9fdb0facfcea561be9'] = 'CMS-Seite für Link';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_01bb71b3e70e9e5057c9678a903d47ac'] = 'wählen Sie eine Seite';
$_MODULE['<{blockpaymentlogo}leogift>blockpaymentlogo_d4dccb8ca2dac4e53c01bd9954755332'] = 'Speichern Sie die Einstellungen';
