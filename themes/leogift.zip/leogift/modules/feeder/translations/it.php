<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{feeder}leogift>feeder_d97c951c07d785b317ffb55c01bf6976'] = 'Feed RSS prodotti.';
$_MODULE['<{feeder}leogift>feeder_b118eb1df6ece770ad9d2bbe97cc1a79'] = 'Crea un Feed RSS prodotti.';
