<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_4f29d8c727dcf2022ac241cb96c31083'] = 'Leerer Datensatz zurückgegeben';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_f5c493141bb4b2508c5938fd9353291a'] = '%1$s von %2$s';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_eebfd2d9a7ea25b9e61e8260bcd4849c'] = 'Insgesamt verkaufte Menge';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_f3547ae5e06426d87312eff7dda775aa'] = 'Gesamtpreis Verkauf';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_c13329e42ec01a10f84c0f950274b404'] = 'Insgesamt angesehen';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_6e3b3150807da868ebd33ad2c991b8d7'] = 'Beliebteste Kategorien';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_a2e1fa19a6a3405a4e82cb5daa66310d'] = 'Eine Liste der besten Kategorien';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
