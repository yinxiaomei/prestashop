<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_4f29d8c727dcf2022ac241cb96c31083'] = 'Aucun résultat retourné';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_f5c493141bb4b2508c5938fd9353291a'] = 'Показано %1$s из %2$s';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_49ee3087348e8d44e1feda1917443987'] = 'Имя';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_eebfd2d9a7ea25b9e61e8260bcd4849c'] = 'Общее проданное количество';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_f3547ae5e06426d87312eff7dda775aa'] = 'Общая стоимость продаж';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_c13329e42ec01a10f84c0f950274b404'] = 'Всего просмотрено';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_6e3b3150807da868ebd33ad2c991b8d7'] = 'Лучшие категории';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_a2e1fa19a6a3405a4e82cb5daa66310d'] = 'Список лучших категорий';
$_MODULE['<{statsbestcategories}leogift>statsbestcategories_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
