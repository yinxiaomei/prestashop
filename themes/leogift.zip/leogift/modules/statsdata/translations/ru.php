<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsdata}leogift>statsdata_a51950bf91ba55cd93a33ce3f8d448c2'] = 'Обработка данных статистики';
$_MODULE['<{statsdata}leogift>statsdata_c77dfd683d0d76940e5e04cb24e8bce1'] = 'Этот модуль должен быть включен, если вы хотите использовать статистику.';
$_MODULE['<{statsdata}leogift>statsdata_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Конфигурация обновлена';
$_MODULE['<{statsdata}leogift>statsdata_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройка';
$_MODULE['<{statsdata}leogift>statsdata_1a5b75c4be3c0100c99764b21e844cc8'] = 'Сохранить количество просмотров страниц для каждого клиента';
$_MODULE['<{statsdata}leogift>statsdata_93cba07454f06a4a960172bbd6e2a435'] = 'Да';
$_MODULE['<{statsdata}leogift>statsdata_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Нет';
$_MODULE['<{statsdata}leogift>statsdata_f3e159134846bd13c0c967f361229233'] = 'Регистрация просмотров страниц клиентами требуют много ресурсов процессора и место на диске.';
$_MODULE['<{statsdata}leogift>statsdata_b368e11d9d23b26f1fb4a1b78584560d'] = 'Сохранить общие просмотры страниц';
$_MODULE['<{statsdata}leogift>statsdata_339acfd90b82e91ce9141ec75e4bff24'] = 'Регистрация общих просмотров страниц использует меньше ресурсов, чем просмотры страниц каждым клиентом, но тем не менее, использует ресурсы.';
$_MODULE['<{statsdata}leogift>statsdata_c0e4406117ba4c29c4d66e3069ebf3d3'] = 'Плагины для отслеживания';
$_MODULE['<{statsdata}leogift>statsdata_7a6cf506bde903b2b30c0a4cbcfa0291'] = 'Плагин отслеживания увеличит объем загрузки на 20 кб (файл javascript) для новых посетителей';
$_MODULE['<{statsdata}leogift>statsdata_06933067aafd48425d67bcb01bba5cb6'] = 'Обновить';
