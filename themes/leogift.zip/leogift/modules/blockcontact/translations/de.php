<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcontact}leogift>blockcontact_0f45a6908556b5b1d7c7d79e60fa3fa7'] = 'Block Kontakt';
$_MODULE['<{blockcontact}leogift>blockcontact_318ed85b9852475f24127167815e85d9'] = 'Ermöglicht Ihnen, weitere Informationen über Ihren Kundenservice hinzuzufügen';
$_MODULE['<{blockcontact}leogift>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{blockcontact}leogift>blockcontact_17870f54a180e69e60e84125f805db67'] = 'Telefon:';
$_MODULE['<{blockcontact}leogift>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-Mail';
$_MODULE['<{blockcontact}leogift>blockcontact_b17f3f4dcf653a5776792498a9b44d6a'] = 'Einstellungen aktualisieren';
$_MODULE['<{blockcontact}leogift>blockcontact_02d4482d332e1aef3437cd61c9bcc624'] = 'Kontaktieren Sie uns';
$_MODULE['<{blockcontact}leogift>blockcontact_75858d311c84e7ba706b69bea5c71d36'] = 'Wir sind 24 Stunden, 7 Tage die Woche, für Sie erreichbar';
$_MODULE['<{blockcontact}leogift>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Telefon-Nr.';
$_MODULE['<{blockcontact}leogift>blockcontact_736c5a7e834b7021bfa97180fc453115'] = 'Nehmen Sie Kontakt mit uns auf';
$_MODULE['<{blockcontact}leogift>blockcontact_8b1f7be76996ad6911a17592b9804e1b'] = 'Wir sind 24 Stunden, 7 Tage die Woche, für Sie erreichbar';
$_MODULE['<{blockcontact}leogift>blockcontact_e6d0e56415c30a59658fb34ef5d7be35'] = 'Nehmen Sie Kontakt mit uns auf';
