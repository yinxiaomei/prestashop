<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}leogift>homefeatured_dcf3f48ad88dabefc99b82013c4443de'] = 'Polecane produkty na stronie głównej';
$_MODULE['<{homefeatured}leogift>homefeatured_33d0c6fa8dcda0ea168f8ef69556acfe'] = 'Wyświetla polecane produkty na środku Twojej strony głównej.';
$_MODULE['<{homefeatured}leogift>homefeatured_8f31eb2413dea86c661532d4cf973d2f'] = 'Błędna ilość produktów';
$_MODULE['<{homefeatured}leogift>homefeatured_6af91e35dff67a43ace060d1d57d5d1a'] = 'Zaktualizowano ustawienia';
$_MODULE['<{homefeatured}leogift>homefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{homefeatured}leogift>homefeatured_4cad5369b27bff0ba256a479a575eb6f'] = 'W celu dodania produktów do swojej strony domowej, po prostu dodaj je do \"głównej\" kategorii.';
$_MODULE['<{homefeatured}leogift>homefeatured_87ae431d2f8285c91660bd00d330a257'] = 'Zdefiniuj ilość wyświetlanych produktów.';
$_MODULE['<{homefeatured}leogift>homefeatured_b263d5a770ca788195f4038d1a0ea6fc'] = 'Zdefiniuj ilość produktów, które mają być wieświetlane na stronie głównej (domyślnie: 8).';
$_MODULE['<{homefeatured}leogift>homefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{homefeatured}leogift>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Produkty polecane';
$_MODULE['<{homefeatured}leogift>homefeatured_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nowe';
$_MODULE['<{homefeatured}leogift>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Więcej';
$_MODULE['<{homefeatured}leogift>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Zobacz';
$_MODULE['<{homefeatured}leogift>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Dodaj do koszyka';
$_MODULE['<{homefeatured}leogift>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Brak polecanych produktów';
