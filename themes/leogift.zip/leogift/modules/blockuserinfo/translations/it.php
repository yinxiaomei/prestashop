<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_a2e9cd952cda8ba167e62b25a496c6c1'] = 'Blocco info utente';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_970a31aa19d205f92ccfd1913ca04dc0'] = 'Aggiungi un blocco che visualizza le informazioni sul cliente.';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_0c3bf3014aafb90201805e45b5e62881'] = 'Vedi il mio carrello';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'Carrello';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_deb10517653c255364175796ace3553f'] = 'Prodotto';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_068f80c7519d0528fb08e82137a72131'] = 'Prodotti';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(vuoto)';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_2cbfb6731610056e1d0aaacde07096c1'] = 'Vedi il mio account';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Il tuo account';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Benvenuto';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Fammi uscire';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'Esci';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_b145abfd6b2f88971d725cbd94a5879f'] = 'Entra nel tuo account';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_99dea78007133396a7b8ed70578ac6ae'] = 'Entra';
