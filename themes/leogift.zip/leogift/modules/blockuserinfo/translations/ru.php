<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_a2e9cd952cda8ba167e62b25a496c6c1'] = 'Блок информации о пользователе';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_970a31aa19d205f92ccfd1913ca04dc0'] = 'Добавляет блок, который отображает информацию о клиенте.';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_0c3bf3014aafb90201805e45b5e62881'] = 'Просмотреть мою корзину';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'Корзина:';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_deb10517653c255364175796ace3553f'] = 'товар';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_068f80c7519d0528fb08e82137a72131'] = 'товара';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(пусто)';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_2cbfb6731610056e1d0aaacde07096c1'] = 'Просмотреть мою учетную запись покупателя';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Ваша учетная запись';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Добро пожаловать';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Выйти';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_4394c8d8e63c470de62ced3ae85de5ae'] = 'Выход';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_b145abfd6b2f88971d725cbd94a5879f'] = 'Войти в вашу учетную запись покупателя';
$_MODULE['<{blockuserinfo}leogift>blockuserinfo_99dea78007133396a7b8ed70578ac6ae'] = 'Вход';
