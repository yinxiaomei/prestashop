<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'Blocco my account nel footer';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'Mostra un blocco con i link relativi all\'account cliente.';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Gestisci il mio account';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Il mio account';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'I miei ordini';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'I miei resi';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'I miei resi di merce';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'Le mie note di credito';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'I miei indirizzi';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Lista delle mie info personali';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'Le mie informazioni personali';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'I miei buoni';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Esci';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_057d295c52fbfa6009018983adfcfef3'] = 'Lista dei miei ordini';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_84717c9dceaf4edb4d68fb83baad9c5b'] = 'Lista dei miei resi';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_adb86424a996157ea978c08a665aa552'] = 'Lista delle mie note di credito';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_ce1f9a653c6297bee14973a2af3c4493'] = 'Lista dei miei indirizzi';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_1f94d078255c7cee3fcfd50c762101e6'] = 'Lista dei miei buoni';
