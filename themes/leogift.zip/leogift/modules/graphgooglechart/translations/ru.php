<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphgooglechart}leogift>graphgooglechart_b3b8abce7e542a30dc415f612d4e0f23'] = 'Google Chart';
$_MODULE['<{graphgooglechart}leogift>graphgooglechart_e01118a336bd13f2f0e70bf7178c1fdc'] = 'Google Chart API позволит динамически генерировать различные графики.';
