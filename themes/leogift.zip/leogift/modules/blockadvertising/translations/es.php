<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}leogift>blockadvertising_fd4c71c948857cce596a69fbaea7426b'] = 'Bloque de publicidad';
$_MODULE['<{blockadvertising}leogift>blockadvertising_91cd1ee56ea5324ff51578684a393a81'] = 'Añadir un bloque para mostrar la publicidad';
$_MODULE['<{blockadvertising}leogift>blockadvertising_070e16b4f77b90e802f789b5be583cfa'] = 'error al desplazar el fichero uploado';
$_MODULE['<{blockadvertising}leogift>blockadvertising_6e7be6d836003f069c00cd217660913b'] = 'Configuración del bloque de publicidad';
$_MODULE['<{blockadvertising}leogift>blockadvertising_a21056e22c4d62b400b5dd96dafe22a3'] = 'No puede suprimir la imagen por defecto (pero puede cambiarla abajo)';
$_MODULE['<{blockadvertising}leogift>blockadvertising_83b5a65e518c21ed0a5f2b383dd9b617'] = 'Eliminar la imagen';
$_MODULE['<{blockadvertising}leogift>blockadvertising_9dd7104e68d1b5f994264b9387c9d271'] = 'Ninguna imagen';
$_MODULE['<{blockadvertising}leogift>blockadvertising_8c38cf08a0d0a01bd44c682479432350'] = 'Cambiar la imagen';
$_MODULE['<{blockadvertising}leogift>blockadvertising_56d9dfa26d7848a3fbcd2ae3091d38d9'] = 'La imagen se mostrará como 155x163.';
$_MODULE['<{blockadvertising}leogift>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Enlace de la imagen';
$_MODULE['<{blockadvertising}leogift>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Título';
$_MODULE['<{blockadvertising}leogift>blockadvertising_ad3d06d03d94223fa652babc913de686'] = 'Validar';
