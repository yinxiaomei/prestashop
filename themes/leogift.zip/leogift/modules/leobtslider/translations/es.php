<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leobtslider}leogift>form_f2a6c498fb90ee345d997f888fce3b18'] = 'borrar';
$_MODULE['<{leobtslider}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Sí.';
$_MODULE['<{leobtslider}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
