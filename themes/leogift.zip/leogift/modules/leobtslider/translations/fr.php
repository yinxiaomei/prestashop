<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leobtslider}leogift>form_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{leobtslider}leogift>form_d2126da975d5b9a5b846efaf57d3fd53'] = 'Configuration générale';
$_MODULE['<{leobtslider}leogift>form_955d20f2bc338c09c7e0f4288cb77c93'] = 'Configuration de source de données';
$_MODULE['<{leobtslider}leogift>form_571988492824e57070d78e6c86333f20'] = 'Configuration des diapositives';
$_MODULE['<{leobtslider}leogift>form_02023fc24279454047fd419ecd1db9af'] = 'Ajouter diapo';
$_MODULE['<{leobtslider}leogift>form_a9884c8f5501dc36b3ae14a380f0013f'] = 'Vous n\'avez pas encore ajouté de diapositives.';
$_MODULE['<{leobtslider}leogift>form_7dce122004969d56ae2e0245cb754d35'] = 'Modifier';
$_MODULE['<{leobtslider}leogift>form_f2a6c498fb90ee345d997f888fce3b18'] = 'Supprimer';
$_MODULE['<{leobtslider}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Qui';
$_MODULE['<{leobtslider}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
