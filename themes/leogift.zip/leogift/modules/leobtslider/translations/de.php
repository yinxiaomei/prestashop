<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leobtslider}leogift>form_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{leobtslider}leogift>leobtslider_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{leobtslider}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Nein';
$_MODULE['<{leobtslider}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Keine';
