<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksocial}leogift>blocksocial_3c3fcc2aa9705117ce4b589ed5a72853'] = 'Block Soziale Netzwerke';
$_MODULE['<{blocksocial}leogift>blocksocial_012a4601e8b615cf6aea084a1b334889'] = 'Ermöglicht Ihnen, zusätzliche Informationen für soziale Netzwerke hinzuzufügen';
$_MODULE['<{blocksocial}leogift>blocksocial_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguration aktualisiert';
$_MODULE['<{blocksocial}leogift>blocksocial_f95f7cbc540537a1010c5b545eb67339'] = 'Facebook-URL:';
$_MODULE['<{blocksocial}leogift>blocksocial_e62adc7f2754307e0a31f145e29f6be1'] = 'Twitter-URL:';
$_MODULE['<{blocksocial}leogift>blocksocial_77e4dcd265e823af4b5d59f6fa23dfa3'] = 'RSS-URL:';
$_MODULE['<{blocksocial}leogift>blocksocial_b17f3f4dcf653a5776792498a9b44d6a'] = 'Einstellungen aktualisieren';
$_MODULE['<{blocksocial}leogift>blocksocial_d918f99442796e88b6fe5ad32c217f76'] = 'Folgen Sie uns';
$_MODULE['<{blocksocial}leogift>blocksocial_d85544fce402c7a2a96a48078edaf203'] = 'Facebook';
$_MODULE['<{blocksocial}leogift>blocksocial_2491bc9c7d8731e1ae33124093bc7026'] = 'Twitter';
$_MODULE['<{blocksocial}leogift>blocksocial_bf1981220040a8ac147698c85d55334f'] = 'RSS';
$_MODULE['<{blocksocial}leogift>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Sonderangebote';
$_MODULE['<{blocksocial}leogift>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Alle Specials';
$_MODULE['<{blocksocial}leogift>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'Keine Sonderangebote zur Zeit';
