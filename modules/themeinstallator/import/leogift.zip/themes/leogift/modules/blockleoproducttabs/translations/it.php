<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_2891e6bd1b6e8b4be99a6941ff6f1ff0'] = 'Miglior Tab venditore';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_aaffcd9ede4a83ea0678e1f8acb0f8bb'] = 'Tab in vetrina';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_a93f0744f60adc61871989817f039d95'] = 'Nuova scheda Arrials';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_b4c2b550635fe54fd29f2b64dfaca55d'] = 'Speciale';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_31d26a6487e08357bd771619e894b0c6'] = 'Nuovi Arrivi';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_22c6735b370cecf293e32dca6c678185'] = 'Migliore venditore';
$_MODULE['<{blockleoproducttabs}leogift>blockleoproducttabs_cf8156f1f57a8603cd6b3a28c9c2c61b'] = 'Prodotti in vetrina';
$_MODULE['<{blockleoproducttabs}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nuovo';
$_MODULE['<{blockleoproducttabs}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Maggiori';
$_MODULE['<{blockleoproducttabs}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Visualizza';
$_MODULE['<{blockleoproducttabs}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aggiungi al carrello';
