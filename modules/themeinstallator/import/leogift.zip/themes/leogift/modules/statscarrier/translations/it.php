<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscarrier}leogift>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Ripartizione per corriere';
$_MODULE['<{statscarrier}leogift>statscarrier_c521b5a8b0e2966709e4338368e59054'] = 'Mostra la ripartizione per corrieri';
$_MODULE['<{statscarrier}leogift>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Tutto';
$_MODULE['<{statscarrier}leogift>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Filtro';
$_MODULE['<{statscarrier}leogift>statscarrier_b4db3f09700b25a1acc487d3488d0216'] = 'Questo grafico rappresenta la ripartizione per corriere dei tuoi ordini. È inoltre possibile limitare a uno stato di ordine.';
$_MODULE['<{statscarrier}leogift>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'Esporta CSV';
$_MODULE['<{statscarrier}leogift>statscarrier_ae916988f1944283efa2968808a71287'] = 'Nessun ordine valido per questo periodo.';
$_MODULE['<{statscarrier}leogift>statscarrier_d5b9d0daaf017332f1f8188ab2a3f802'] = 'Percentuale degli ordini per corriere.';
