<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscarrier}leogift>statscarrier_2e6774abc54cb13cef2c5bfd5a2cb463'] = 'Службы доставки';
$_MODULE['<{statscarrier}leogift>statscarrier_c521b5a8b0e2966709e4338368e59054'] = 'Показывает список служб доставки товаров';
$_MODULE['<{statscarrier}leogift>statscarrier_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Все';
$_MODULE['<{statscarrier}leogift>statscarrier_d7778d0c64b6ba21494c97f77a66885a'] = 'Фильтр';
$_MODULE['<{statscarrier}leogift>statscarrier_b4db3f09700b25a1acc487d3488d0216'] = 'Этот график представляет распределение способов доставки  ваших заказов. Вы также можете ограничить его по заказам в одном государстве.';
$_MODULE['<{statscarrier}leogift>statscarrier_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statscarrier}leogift>statscarrier_ae916988f1944283efa2968808a71287'] = 'Нет заказов за указанный период.';
$_MODULE['<{statscarrier}leogift>statscarrier_d5b9d0daaf017332f1f8188ab2a3f802'] = 'Процент заказов через службы доставки';
