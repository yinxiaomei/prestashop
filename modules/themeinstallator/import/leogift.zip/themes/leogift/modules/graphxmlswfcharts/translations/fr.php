<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphxmlswfcharts}leogift>graphxmlswfcharts_fd1d6df8df2837bc1690e3ca9d84f502'] = 'XML/SWF Charts';
$_MODULE['<{graphxmlswfcharts}leogift>graphxmlswfcharts_723f92861aa774c9d255e0b8c42c29e8'] = 'XML/SWF Charts est un outil simple mais puissant utilisant Adobe Flash pour créer des graphiques à partir de données dynamiques.';
