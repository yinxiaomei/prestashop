<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphxmlswfcharts}leogift>graphxmlswfcharts_fd1d6df8df2837bc1690e3ca9d84f502'] = 'Cartas  XML/SWF';
$_MODULE['<{graphxmlswfcharts}leogift>graphxmlswfcharts_723f92861aa774c9d255e0b8c42c29e8'] = 'Las cartas de XML/SWF son unas herramientas simples, de un gran alcance, que pueden usar el flash de Adobe para crear cartas y gráficos atractivos de datos dinámicos.';
