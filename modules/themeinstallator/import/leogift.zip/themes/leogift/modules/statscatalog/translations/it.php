<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscatalog}leogift>statscatalog_cf3aa21c6a2147ddbd86f34091daeccd'] = 'Catalogo statistiche';
$_MODULE['<{statscatalog}leogift>statscatalog_226ed1224c5b2db3d3e0716bb4f74da5'] = 'Statistiche generali sul tuo catalogo.';
$_MODULE['<{statscatalog}leogift>statscatalog_74cda5a02df704cc5c3e8fee7fc0f7bc'] = '(1 acquisto / %d visite)';
$_MODULE['<{statscatalog}leogift>statscatalog_0173374ac20f5843d58b553d5b226ef6'] = 'Scegli una categoria';
$_MODULE['<{statscatalog}leogift>statscatalog_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Tutto';
$_MODULE['<{statscatalog}leogift>statscatalog_a7b623414d4b6a3225b4e935babec6d2'] = 'Prodotti disponibili:';
$_MODULE['<{statscatalog}leogift>statscatalog_1099377f1598a0856e2457a5145d89c2'] = 'Prezzo medio (prezzo base):';
$_MODULE['<{statscatalog}leogift>statscatalog_48a93dc02c74f3065af1ba47fca070d0'] = 'Pagine viste del prodotto:';
$_MODULE['<{statscatalog}leogift>statscatalog_156e5c5872c9af24a5c982da07a883c2'] = 'I prodotti acquistati:';
$_MODULE['<{statscatalog}leogift>statscatalog_85f179d4142ca061d49605a7fffdc09d'] = 'Numero medio di visite pagina:';
$_MODULE['<{statscatalog}leogift>statscatalog_05ff4bfc3baf0acd31a72f1ac754de04'] = 'Numero medio di acquisti:';
$_MODULE['<{statscatalog}leogift>statscatalog_c09d09e371989d89847049c9574b6b8e'] = 'Immagini disponibili:';
$_MODULE['<{statscatalog}leogift>statscatalog_65275d1b04037d8c8e42425002110363'] = 'Numero medio di immagini:';
$_MODULE['<{statscatalog}leogift>statscatalog_51b8891d531ad91128ba58c8928322ab'] = 'I prodotti mai visti:';
$_MODULE['<{statscatalog}leogift>statscatalog_8725647ef741e5d48c1e6f652ce80b50'] = 'Prodotti mai comprati:';
$_MODULE['<{statscatalog}leogift>statscatalog_b86770bc713186bcf43dbb1164c5fd28'] = 'Tasso di conversione *:';
$_MODULE['<{statscatalog}leogift>statscatalog_0468e0edbf9f5807c25c106248bd7401'] = 'Tasso medio di conversione per la pagina del prodotto. E\' possibile acquistare un prodotto senza visualizzare la pagina del prodotto, quindi questo tasso può essere maggiore di 1.';
$_MODULE['<{statscatalog}leogift>statscatalog_58a714d3e9bb2902a5b688c99bd4d8e6'] = 'Prodotti mai comprati';
$_MODULE['<{statscatalog}leogift>statscatalog_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statscatalog}leogift>statscatalog_49ee3087348e8d44e1feda1917443987'] = 'Nome';
$_MODULE['<{statscatalog}leogift>statscatalog_8e7c9a35104a5a68199678bd6bc5d187'] = 'Modifica / Visualizza';
