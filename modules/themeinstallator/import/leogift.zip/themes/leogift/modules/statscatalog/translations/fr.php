<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statscatalog}leogift>statscatalog_cf3aa21c6a2147ddbd86f34091daeccd'] = 'Statistiques du catalogue';
$_MODULE['<{statscatalog}leogift>statscatalog_226ed1224c5b2db3d3e0716bb4f74da5'] = 'Statistiques générales sur le catalogue';
$_MODULE['<{statscatalog}leogift>statscatalog_74cda5a02df704cc5c3e8fee7fc0f7bc'] = '(1 achat / %d visites)';
$_MODULE['<{statscatalog}leogift>statscatalog_0173374ac20f5843d58b553d5b226ef6'] = 'Choisissez une catégorie';
$_MODULE['<{statscatalog}leogift>statscatalog_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Toutes';
$_MODULE['<{statscatalog}leogift>statscatalog_a7b623414d4b6a3225b4e935babec6d2'] = 'Produits disponibles :';
$_MODULE['<{statscatalog}leogift>statscatalog_1099377f1598a0856e2457a5145d89c2'] = 'Prix moyen (HT) :';
$_MODULE['<{statscatalog}leogift>statscatalog_48a93dc02c74f3065af1ba47fca070d0'] = 'Pages produit vues :';
$_MODULE['<{statscatalog}leogift>statscatalog_156e5c5872c9af24a5c982da07a883c2'] = 'Produits achetés :';
$_MODULE['<{statscatalog}leogift>statscatalog_85f179d4142ca061d49605a7fffdc09d'] = 'Nombre moyen de visites :';
$_MODULE['<{statscatalog}leogift>statscatalog_05ff4bfc3baf0acd31a72f1ac754de04'] = 'Nombre moyen d\'achats :';
$_MODULE['<{statscatalog}leogift>statscatalog_c09d09e371989d89847049c9574b6b8e'] = 'Images disponibles :';
$_MODULE['<{statscatalog}leogift>statscatalog_65275d1b04037d8c8e42425002110363'] = 'Nombre moyen d\'images :';
$_MODULE['<{statscatalog}leogift>statscatalog_51b8891d531ad91128ba58c8928322ab'] = 'Produits jamais consultés :';
$_MODULE['<{statscatalog}leogift>statscatalog_8725647ef741e5d48c1e6f652ce80b50'] = 'Produits jamais achetés :';
$_MODULE['<{statscatalog}leogift>statscatalog_b86770bc713186bcf43dbb1164c5fd28'] = 'Taux de transformation* :';
$_MODULE['<{statscatalog}leogift>statscatalog_0468e0edbf9f5807c25c106248bd7401'] = 'Taux de transformation moyen pour une page produit. Un produit pouvant être acheté sans passer par sa page dédiée, cet indicateur peut être supérieur à 1.';
$_MODULE['<{statscatalog}leogift>statscatalog_58a714d3e9bb2902a5b688c99bd4d8e6'] = 'Produits jamais achetés';
$_MODULE['<{statscatalog}leogift>statscatalog_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statscatalog}leogift>statscatalog_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statscatalog}leogift>statscatalog_8e7c9a35104a5a68199678bd6bc5d187'] = 'Modifier / Voir';
