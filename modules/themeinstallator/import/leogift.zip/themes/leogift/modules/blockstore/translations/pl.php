<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}leogift>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Blok sklepów';
$_MODULE['<{blockstore}leogift>blockstore_2d7884c3777bd04028c4a55a820880a8'] = 'Wyświetlaj blok z linkiem do lokalizacji sklepów.';
$_MODULE['<{blockstore}leogift>blockstore_126b21ce46c39d12c24058791a236777'] = 'nieprawidłowy obrazek';
$_MODULE['<{blockstore}leogift>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'błąd poczas wysyłania pliku';
$_MODULE['<{blockstore}leogift>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Ustawienia odświeżone';
$_MODULE['<{blockstore}leogift>blockstore_151e79863510ec66281329505bf9fbde'] = 'Konfiguracja bloku sklepów';
$_MODULE['<{blockstore}leogift>blockstore_2dd1d28275cdb8b78ebd17f6e25aac0d'] = 'Zdjęcie sklepu';
$_MODULE['<{blockstore}leogift>blockstore_8c38cf08a0d0a01bd44c682479432350'] = 'Zmień zdjęcie';
$_MODULE['<{blockstore}leogift>blockstore_3eedfc0fbc9042acf0ecfe0f325428c4'] = 'Obrazek będzie wyświetlony w wielkości 174x115';
$_MODULE['<{blockstore}leogift>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{blockstore}leogift>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'Nasze sklepy';
$_MODULE['<{blockstore}leogift>blockstore_142fe29b7422147cdac10259a0333c11'] = 'Odkryj nasze sklepy';
$_MODULE['<{blockstore}leogift>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Nasze sklepy';
$_MODULE['<{blockstore}leogift>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Odkryj nasze sklepy';
