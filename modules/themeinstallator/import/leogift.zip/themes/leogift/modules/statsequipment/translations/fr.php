<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsequipment}leogift>statsequipment_719d067b229178f03bcfa1da4ac4dede'] = 'Équipement';
$_MODULE['<{statsequipment}leogift>statsequipment_236d6d0b5cc4428f346c235e0c60faaa'] = 'Affiche l\'équipement de vos visiteurs.';
$_MODULE['<{statsequipment}leogift>statsequipment_d36312e9992d0b03780a32fedd6650b7'] = 'Déterminez la répartition des navigateurs web utilisés par vos clients.';
$_MODULE['<{statsequipment}leogift>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{statsequipment}leogift>statsequipment_c560add3373d03ea2723069fb428719a'] = 'Déterminez la répartition des systèmes d\'exploitation utilisés par vos clients.';
$_MODULE['<{statsequipment}leogift>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Extensions';
$_MODULE['<{statsequipment}leogift>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsequipment}leogift>statsequipment_501361472d0528ee07f202297f599d40'] = 'Veillez à ce que votre site soit accessible à tous.';
$_MODULE['<{statsequipment}leogift>statsequipment_ef83f5147398f2735fddfaac983983d7'] = 'Navigateurs utilisés';
$_MODULE['<{statsequipment}leogift>statsequipment_0a66f998cfad4890a14c9b9a1df8deb3'] = 'Systèmes d\'exploitation utilisés';
