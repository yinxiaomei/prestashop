<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksharefb}leogift>blocksharefb_cbe5bf6cf027e9f9e6cc0e8d725ebfa6'] = 'Blocco condividi su Facebook.';
$_MODULE['<{blocksharefb}leogift>blocksharefb_f96f72b5ba39796e728cc55ddd1672cb'] = 'Permetti ai clienti di condividere i tuoi prodotti o il contenuto del suo sito su Facebook.';
$_MODULE['<{blocksharefb}leogift>blocksharefb_353005a70db1e1dac3aadedec7596bd7'] = 'Condividi su Facebook!';
