<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcategories}leogift>blockcategories_8f0ed7c57fca428f7e3f8e64d2f00918'] = 'Bloque de categorías';
$_MODULE['<{blockcategories}leogift>blockcategories_15a6f5841d9e4d7e62bec3319b4b7036'] = 'Añdir un bloque que ofrezca categorías de productos';
$_MODULE['<{blockcategories}leogift>blockcategories_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Nivel máximo: Número incorrecto';
$_MODULE['<{blockcategories}leogift>blockcategories_0cf328636f0d607ac24a5c435866b94b'] = 'HTML dinámico: opción no válida';
$_MODULE['<{blockcategories}leogift>blockcategories_c888438d14855d7d96a2724ee9c306bd'] = 'Configuración actualizada';
$_MODULE['<{blockcategories}leogift>blockcategories_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{blockcategories}leogift>blockcategories_19561e33450d1d3dfe6af08df5710dd0'] = 'Nivel máximo';
$_MODULE['<{blockcategories}leogift>blockcategories_ef35cd8f1058f29151991e9ca94b36fb'] = 'Seleccione el nivel máximo de subniveles a mostrar en este bloque (0=infinito)';
$_MODULE['<{blockcategories}leogift>blockcategories_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'Dinámico';
$_MODULE['<{blockcategories}leogift>blockcategories_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{blockcategories}leogift>blockcategories_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{blockcategories}leogift>blockcategories_e16f248b047fb7d0c97dcc19b17296a3'] = 'Modo dinámico activado (animado) para los subniveles';
$_MODULE['<{blockcategories}leogift>blockcategories_6b46ae48421828d9973deec5fa9aa0c3'] = 'Orden';
$_MODULE['<{blockcategories}leogift>blockcategories_883f0bd41a4fcee55680446ce7bec0d9'] = 'Por posición';
$_MODULE['<{blockcategories}leogift>blockcategories_54e4f98fb34254a6678f0795476811ed'] = 'Por nombre';
$_MODULE['<{blockcategories}leogift>blockcategories_cf3fb1ff52ea1eed3347ac5401ee7f0c'] = 'Ascendente';
$_MODULE['<{blockcategories}leogift>blockcategories_e3cf5ac19407b1a62c6fccaff675a53b'] = 'Descendente';
$_MODULE['<{blockcategories}leogift>blockcategories_5f73e737cedf8f4ccf880473a7823005'] = 'Número de columnas para el footer';
$_MODULE['<{blockcategories}leogift>blockcategories_d5e74c74b1457c285adc8b2c2ab03767'] = 'Determina el número de columnas para el footer';
$_MODULE['<{blockcategories}leogift>blockcategories_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcategories}leogift>blockcategories_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorías';
$_MODULE['<{blockcategories}leogift>blockcategories_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'Categorías';
