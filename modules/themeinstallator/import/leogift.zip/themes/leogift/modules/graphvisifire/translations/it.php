<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphvisifire}leogift>graphvisifire_46495d329b07c973daa82a7a9c084d6b'] = 'Visifire';
$_MODULE['<{graphvisifire}leogift>graphvisifire_8fb4e2a61c48721ee73f9b9189fd19e1'] = 'Visifire è un insieme di componenti di visualizzazione dei dati open source powered by Microsoft Silverlight 2 beta 2.';
