<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{lofadvancecustom}leogift>popup_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{lofadvancecustom}leogift>lofadvancecustom_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{lofadvancecustom}leogift>params_cc3787ca78f445f481069a4c047f7e7a'] = 'Choisissez la langue:';
