<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{lofadvancecustom}leogift>lofadvancecustom_8fc0ad049ba7b756bc2e70886fdaeed7'] = 'Lof Avance Pie de módulo';
$_MODULE['<{lofadvancecustom}leogift>lofadvancecustom_21efafa62ac903fa766465b46cd0c4b1'] = 'Configuración actualizado con éxito';
$_MODULE['<{lofadvancecustom}leogift>lofadvancecustom_b361125f24c37d45962667a3f690a12a'] = 'Eliminar Bloque éxito';
$_MODULE['<{lofadvancecustom}leogift>lofadvancecustom_0e2d440d8461d36bc8c8a4d5768ad1e8'] = 'Eliminar error Bloquear';
$_MODULE['<{lofadvancecustom}leogift>params_cc3787ca78f445f481069a4c047f7e7a'] = 'Elige idioma:';
