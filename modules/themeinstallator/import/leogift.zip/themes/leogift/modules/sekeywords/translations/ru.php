<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sekeywords}leogift>sekeywords_65b0b42febc8ea16db4652eab6f420a4'] = 'Ключевые слова поисковой машины';
$_MODULE['<{sekeywords}leogift>sekeywords_de13be6263895a5efe4d51e15ab1535e'] = 'Показать, какие ключевые слова привели посетителей на ваш сайт.';
$_MODULE['<{sekeywords}leogift>sekeywords_16d5f8dc3bc4411c85848ae9cf6a947a'] = '%d ключевое слово соответствует вашему запросу.';
$_MODULE['<{sekeywords}leogift>sekeywords_5029f8eef402bb8ddd6191dffb5e7c19'] = '%d ключевых слов, соответствующих вашему запросу.';
$_MODULE['<{sekeywords}leogift>sekeywords_867343577fa1f33caa632a19543bd252'] = 'Ключевые слова';
$_MODULE['<{sekeywords}leogift>sekeywords_e52e6aa1a43a0187e44f048f658db5f9'] = 'Найдено';
$_MODULE['<{sekeywords}leogift>sekeywords_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
$_MODULE['<{sekeywords}leogift>sekeywords_0849140171616600e8f2c35f0a225212'] = 'Фильтр по ключевым словам';
$_MODULE['<{sekeywords}leogift>sekeywords_6e632566b6e16dbd2273e83d7c53182b'] = 'и минимум вхождений';
$_MODULE['<{sekeywords}leogift>sekeywords_fa73b7cd0d2681f6d871c9ef4023ad39'] = 'Применить';
$_MODULE['<{sekeywords}leogift>sekeywords_7b48f6cc4a1dde7fca9597e717c2465f'] = 'Нет слов';
$_MODULE['<{sekeywords}leogift>sekeywords_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{sekeywords}leogift>sekeywords_9ed50bd6876a9273f2192c224b87657b'] = 'Определение внешних поисковых ключевых слов';
$_MODULE['<{sekeywords}leogift>sekeywords_6534eadba477de8a632ff59ac20b572f'] = 'Поисковая система является одним из основных способов для нахождения вебсайтов.';
$_MODULE['<{sekeywords}leogift>sekeywords_0d7ce5d105706cedba41887d3f1c0ea1'] = 'Идентификация самых популярных ключевых слов, введенных вашими посетителями, позволяет вам видеть какие продукты вам следует разместить на главной странице для привлечения новых посетителей и потенциальных покупателей.';
$_MODULE['<{sekeywords}leogift>sekeywords_359f9e79e746fa9f684e5cda9e60ca2e'] = 'Как это работает?';
$_MODULE['<{sekeywords}leogift>sekeywords_722e091cccbd9a9ec8f4a35bf1f35893'] = 'Когда посетитель заходит на ваш сайт, сервер определяет его предыдущее расположение. Этот модуль выделяет ключевые слова с помощью обработки URL .';
$_MODULE['<{sekeywords}leogift>sekeywords_d8b08c48a8d8e739399594adec89458a'] = 'На даннный момент, он может обрабатывать следующие поисковые системы: %1$s и %2$s.';
$_MODULE['<{sekeywords}leogift>sekeywords_50dca930b804e845a852512b44d51c52'] = 'Скоро можно будет динамически добавлять новые поисковые машины и получать свой вариант модуля.';
$_MODULE['<{sekeywords}leogift>sekeywords_e15832aa200f342e8f4ab580b43a72a8'] = '10 первых ключевых слов';
$_MODULE['<{sekeywords}leogift>sekeywords_52ef9633d88a7480b3a938ff9eaa2a25'] = 'Другие';
