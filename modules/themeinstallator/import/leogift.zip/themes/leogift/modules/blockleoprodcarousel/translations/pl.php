<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleoprodcarousel}leogift>blockleoprodcarousel_db5bbee0cb649caceaa88f704351ac80'] = 'Ultimi Prodotti';
$_MODULE['<{blockleoprodcarousel}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nowa';
$_MODULE['<{blockleoprodcarousel}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Więcej';
$_MODULE['<{blockleoprodcarousel}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Wyświetl';
$_MODULE['<{blockleoprodcarousel}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Dodaj do koszyka';
