<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_873330fc1881555fffe2bc471d04bf5d'] = 'Bloc réassurance';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_7e7f70db3c75e428db8e2d0a1765c4e9'] = 'Ajoute un bloc pour afficher des informations pour rassurer vos clients';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_d52eaeff31af37a4a7e0550008aff5df'] = 'Une erreur est survenue lors de la sauvegarde';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'Configuration mise à jour';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_b90a3740c94a99c0f0f2f32efdcfae0a'] = 'Nouveau bloc réassurance';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_461900b74731e07320ca79366df3e809'] = 'Image :';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Texte :';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_630f6dc397fe74e52d5189e2c80f282b'] = 'Retour à la liste';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_490aa6e856ccf208a054389e47ce0d06'] = 'ID';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Texte';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_23498d91b6017e5d7f4ddde70daba286'] = 'ID de la boutique';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_ef61fb324d729c341ea8ab9901e23566'] = 'Ajouter';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_f3295a93167b56c5a19030e91823f7bf'] = 'Satisfait ou remboursé';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_56e140ebd6f399c22c8859a694b247f3'] = 'Échange en magasin';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_597ce11744f9bbf116ec9e4a719ec9d3'] = 'Paiement à l\'expédition';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_3aca7ac5cf7e462b658960931946f824'] = 'Livraison gratuite';
$_MODULE['<{blockreinsurance}leogift>blockreinsurance_d05244e0e410a6b85ed53a014908c657'] = 'Paiement 100% sécurisé';
