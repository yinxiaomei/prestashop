<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_8c4d7af5f578693f9a6cf391e912ee33'] = 'Leere Datensätze erhalten';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_f5c493141bb4b2508c5938fd9353291a'] = '%1$s von %2$s';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_12d3c7a4296542c62474856ec452c045'] = 'Ref.';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_49ee3087348e8d44e1feda1917443987'] = 'Name';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_2a0440eec72540c5b30d9199c01f348c'] = 'Verkaufte Menge';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6771f2d557a34bd89ea7abc92a0a069c'] = 'Verkaufspreis';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Verkäufe';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_96e887520933606d3928a4ae164fe5e5'] = 'Verkaufte Menge/Tag';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_7664a37e0cc56aaf39aebf2edbd3f98e'] = 'Angesehene Seite';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6e71d214907cd43403f4bbde5731a9a3'] = 'Lagerbestand für Verkauf';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_b9ef20f6c20406b631db52374a519b1f'] = 'Beliebteste Produkte';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_dec6192cbc59ba37d38a3fdc5c3ed7f7'] = 'Übersicht der beliebtesten Produkte';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_998e4c5c80f27dec552e99dfed34889a'] = 'CSV-Export';
