<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_8c4d7af5f578693f9a6cf391e912ee33'] = 'Aucun résultat';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_f5c493141bb4b2508c5938fd9353291a'] = 'Affichage de %1$s de %2$s';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_12d3c7a4296542c62474856ec452c045'] = 'Réf.';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_2a0440eec72540c5b30d9199c01f348c'] = 'Qté vendue';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6771f2d557a34bd89ea7abc92a0a069c'] = 'Prix de vente';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Ventes';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_96e887520933606d3928a4ae164fe5e5'] = 'Qté vendue / jour';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_7664a37e0cc56aaf39aebf2edbd3f98e'] = 'Pages vues';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_6e71d214907cd43403f4bbde5731a9a3'] = 'Quantités disponibles à la vente';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_b9ef20f6c20406b631db52374a519b1f'] = 'Meilleurs produits';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_dec6192cbc59ba37d38a3fdc5c3ed7f7'] = 'Liste des meilleurs produits';
$_MODULE['<{statsbestproducts}leogift>statsbestproducts_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
