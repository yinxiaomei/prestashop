<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gamification}leogift>gamification_3d4aafb2eedeba2fbf92e852f0af745a'] = 'Experiencia Merchant';
$_MODULE['<{gamification}leogift>gamification_bacc1bf300527bad9c6ac2d3b875a8d8'] = 'Conviértase en un experto en el comercio electrónico en un abrir y cerrar de ojos!';
$_MODULE['<{gamification}leogift>view_2a0ab6a9172272d54f0d601b0ac157f3'] = 'Conviértase en un experto de comercio electrónico a pasos agigantados!';
$_MODULE['<{gamification}leogift>view_8ba134cf899d862079bbf3964bc7d7d4'] = 'Nuestro equipo está disponible para ayudarle a progresar ... Contacte con nosotros ahora!';
