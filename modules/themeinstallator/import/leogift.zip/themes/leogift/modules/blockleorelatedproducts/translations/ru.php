<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_4aae87211f77aada2c87907121576cfe'] = 'другие продукты в той же категории:';
$_MODULE['<{blockleorelatedproducts}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'новое';
$_MODULE['<{blockleorelatedproducts}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'больше';
$_MODULE['<{blockleorelatedproducts}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'cмотреть';
$_MODULE['<{blockleorelatedproducts}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Добавить в корзину';
