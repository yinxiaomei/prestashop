<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_4aae87211f77aada2c87907121576cfe'] = 'andere Produkte der gleichen Kategorie:';
$_MODULE['<{blockleorelatedproducts}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Nein';
$_MODULE['<{blockleorelatedproducts}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Keine';
$_MODULE['<{blockleorelatedproducts}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Neue';
$_MODULE['<{blockleorelatedproducts}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Mehr';
$_MODULE['<{blockleorelatedproducts}leogift>products_4351cfebe4b61d8aa5efa1d020710005'] = 'Anzeigen';
$_MODULE['<{blockleorelatedproducts}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'In den Warenkorb';
