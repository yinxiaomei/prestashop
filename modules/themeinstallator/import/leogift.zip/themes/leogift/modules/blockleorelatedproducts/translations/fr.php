<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_876b62c6cff1d65b3465df83123be02f'] = 'Leo Produits Associés Bloquer	';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_1666b78ee26e3234f03b1b0a6fe7fd49'] = 'Afficher les produits dans la même catégorie ou Rapporté par Tag .... dans le carrousel.	';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Paramètres mis à jour	';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_3c7679577cd1d0be2b98faf898cfc56d'] = 'Date d\'insertion	';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_235e70e4e7c0a3d61ccb6f60518ebd24'] = 'Date d\'insertion DESC	';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_49ee3087348e8d44e1feda1917443987'] = 'Nom	';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_1b7bb88b3317fe166424fa9e7535e1a9'] = 'Nom DESC	';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockleorelatedproducts}leogift>blockleorelatedproducts_38070661d5ad384d9c7d21895dc4e784'] = 'Produits associés	';
$_MODULE['<{blockleorelatedproducts}leogift>params_93cba07454f06a4a960172bbd6e2a435'] = 'Qui';
$_MODULE['<{blockleorelatedproducts}leogift>params_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{blockleorelatedproducts}leogift>products_03c2e7e41ffc181a4e84080b4710e81e'] = 'Nouveau';
$_MODULE['<{blockleorelatedproducts}leogift>products_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';
$_MODULE['<{blockleorelatedproducts}leogift>products_2d96bb66d8541a89620d3c158ceef42b'] = 'Ajouter à mes favoris	';
$_MODULE['<{blockleorelatedproducts}leogift>products_723edf7c24638ed18d2fa831e647a5cc'] = 'liste	';
$_MODULE['<{blockleorelatedproducts}leogift>products_1f83af4e41052f8eb52dec322580a88d'] = 'comparer	';
$_MODULE['<{blockleorelatedproducts}leogift>products_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Plus';
