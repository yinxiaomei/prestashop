<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Seiten nicht gefunden';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_220b13b2c5c94e16c5895e3925270617'] = 'Anzeige der Seiten, die Besucher aufrufen wollten, aber nicht gefunden haben';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_da4c19289501755f54f1a9223d0271cc'] = '\"Nicht gefundene Seiten\" wurde geleert.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_23dbe39a97cb7e4e528f25f5795d317f'] = 'Nicht gefundene Seiten wurden entfernt.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6b4cd0cb089425011df02c8e86a1b832'] = 'Sie benötigen eine .htaccess-Datei, um 404-Fehler auf die Seite \"404.php\" umzuleiten';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Seite';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referrer';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Zähler';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Keine Seiten registriert';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Leere Datenbank';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_4613b06701504f4a6664effb977b3e32'] = 'Leeren Sie ALLE \"Seite nicht gefunden\" für diesen Zeitraum';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'ALLE /////\"Seite nicht gefunden/////\" löschen';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Erklärung';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = '404-Fehler';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Wie fängt man diese Fehler ab?';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_f0698625adc9935b9a8d40eb128922c2'] = 'Falls Ihr Provider die .htaccess-Datei unterstützt, können Sie sie im Root-Verzeichnis von PrestaShop erstellen und folgende Zeile einfügen:';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_54c5be2cbf4d4a829069fd28903507b0'] = 'Ein Benutzer, der eine Seite aufruft, die es nicht gibt, wird zu dieser Seite weitergeleitet';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_499066312cb6ca89c060f67dcad7c7a6'] = 'Dieses Modul protokolliert die Zugänge zu dieser Seite: die aufgerufene Seite, den Referrer und die Anzahl der Aufrufe.';
