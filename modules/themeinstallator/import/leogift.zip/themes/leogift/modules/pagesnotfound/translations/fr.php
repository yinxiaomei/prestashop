<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Pages introuvables';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_220b13b2c5c94e16c5895e3925270617'] = 'Affiche les pages demandées mais qui n\'existent pas';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_da4c19289501755f54f1a9223d0271cc'] = 'Les pages introuvables vidées.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_23dbe39a97cb7e4e528f25f5795d317f'] = 'Les pages introuvables supprimées.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6b4cd0cb089425011df02c8e86a1b832'] = 'Vous devez utiliser un fichier .htaccess redirigeant les erreurs 404 vers la page \"404.php\"';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Page';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Origine';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Compteur';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Aucune page enregistrée';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Suppression';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_4613b06701504f4a6664effb977b3e32'] = 'Supprimer toutes les pages introuvables sur cette période';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'Supprimer toutes les pages introuvables';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'Erreurs 404';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Comment attraper ces erreurs ?';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_f0698625adc9935b9a8d40eb128922c2'] = 'Si votre hébergeur autorise les fichiers .htaccess, vous pouvez en créer un à la racine de votre PrestaShop et insérer la ligne suivante :';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_54c5be2cbf4d4a829069fd28903507b0'] = 'Un utilisateur qui demande une page inexistante sera redirigé vers la page.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_499066312cb6ca89c060f67dcad7c7a6'] = 'Ce module enregistre les accès à cette page avec : la page demandée initialement, la page source et le nombre de fois que c\'est arrivé.';
