<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Pagine non trovate';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_220b13b2c5c94e16c5895e3925270617'] = 'Visualizza le pagine richieste dai visitatori ma non trovate.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_da4c19289501755f54f1a9223d0271cc'] = 'Pagine non trovate chche svuotata.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_23dbe39a97cb7e4e528f25f5795d317f'] = 'Pagine non trovate eliminate.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6b4cd0cb089425011df02c8e86a1b832'] = 'È necessario utilizzare un file. Htaccess per reindirizzare gli errori 404 alla pagina \"404.php\"';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Pagina';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referente';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contatore';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d372ffc9065cb7d2ea24df137927d060'] = 'Nessuna pagina registrata';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Database vuoto';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_4613b06701504f4a6664effb977b3e32'] = 'Svuotare tutte le pagine non si trova in questo periodo';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_254b5e94768b90388cc7002d362351f0'] = 'Elimina TUTTE le pagine non trovate';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'errori 404';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Come individuare questi errori?';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_f0698625adc9935b9a8d40eb128922c2'] = 'Se il tuo provider supporta il file .htaccess, è possibile crearlo nella directory principale di PrestaShop e inserirvi dentro la seguente riga:';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_54c5be2cbf4d4a829069fd28903507b0'] = 'Un utente che richiede una pagina che non esiste verrà reindirizzato alla seguente pagina.';
$_MODULE['<{pagesnotfound}leogift>pagesnotfound_499066312cb6ca89c060f67dcad7c7a6'] = 'Questo modulo registra gli accessi a questa pagina: la pagina richiesta, la provenienza e il numero di volte che si è verificato.';
