<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_f2ec0fd2abc5714608241a1a0eac321b'] = 'Blocco privacy dati dei clienti.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_cb6b92b60c9302e74a26ac246d0af0fa'] = 'Aggiunge un blocco per visualizzare un messaggio circa la privacy dei dati dei clienti.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'I dati personali che fornisci sono usati per rispondere alle tue richieste, trattare i tuoi ordini o permetterti di accedere a delle informazioni specifiche.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_b43d08355db3df47796e65c72cfd5714'] = 'Hai il diritto di modificare e cancellare tutte le tue informazioni personali nella pagina \"Il mio account\".';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configurazione aggiornata';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_d8b716e21c731aba4b94ba9f3ac4858c'] = 'Messaggio per la privacy dei dati dei clienti.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Messaggio che verrà visualizzato sotto forma di creazione dell\'account.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Consiglio: Ricorda che, se il testo è troppo lungo per essere scritto direttamente nella finestrella, puoi aggiungere un link ad una delle tue pagine create grazie alla pagina \"CMS\" sotto il menu \"Preferenze\".';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Si prega di concordare con la riservatezza dei dati dei clienti spuntando la casella qui sotto.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Privacy dei dati dei clienti';
