<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_f2ec0fd2abc5714608241a1a0eac321b'] = 'Блок конфиденциальности данных о клиентах';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_cb6b92b60c9302e74a26ac246d0af0fa'] = 'Добавляет блок, отображающий сообщение о конфиденциальности данных о клиентах.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Личные данные, которые вы предоставляете, используются для обработки ваших заказов и сообщений, а так же для обеспечения доступа к интересующей вас информации.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_b43d08355db3df47796e65c72cfd5714'] = 'Вы имеете право изменить и удалить любые ваши персональные данные на странице \"Моя учетная запись\"';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Конфигурация обновлена';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_d8b716e21c731aba4b94ba9f3ac4858c'] = 'Сообщение для конфиденциальности данных о клиентах';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Сообщение, которое отображено в форме создания счета.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Подсказка: помните, что если текст слишком длинный и не помещается в форму, вы можете добавить ссылку на одну из ваших страниц, созданных на странице \"CMS\" в меню \"Настройки\".';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Пожалуйста, согласитесь с правилами обработки конфиденциальных данных о клиентах, поставив флажок ниже.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Конфиденциальность данных о клиентах';
