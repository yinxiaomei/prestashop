<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_f2ec0fd2abc5714608241a1a0eac321b'] = 'Blok Ochrona danych osobowych';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_cb6b92b60c9302e74a26ac246d0af0fa'] = 'Dodaje blok wyświetlający informacje o przetwarzaniu danych osobowych';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Dane osobiste które nam przekazujesz użyte są aby odpowiedzieć na Twoje zapytania, przetworzyć Twoje zamówienia lub zezwolić Ci na dostęp do specyficznych informacji.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_b43d08355db3df47796e65c72cfd5714'] = 'Masz prawo modyfikować i usuwać wszystkie informacje osobiste o Tobie które przechowujemy na stronie „Moje konto”.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Konfiguracja zaktualizowana';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_d8b716e21c731aba4b94ba9f3ac4858c'] = 'Wiadomość o przetwarzaniu danych osobowych';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Wiadomość, która zostanie wyświetlona w formularzu zakładania nowego konta klienta';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_b51d73fb490ad1245fa9b87042bbbbb7'] = 'Wskazówki: Pamiętaj, że jeżeli tekst jest zbyt długi aby go wpisać bezpośrednio do formularza, może podać link do jednej z Twoich stron stworzonej za pomocą strony „CMS” w menu „Preferencje”.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Nie można założyć konta z powodu braku zgody na przetwarzanie danych osobowych.';
$_MODULE['<{blockcustomerprivacy}leogift>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Ochrona danych osobowych';
