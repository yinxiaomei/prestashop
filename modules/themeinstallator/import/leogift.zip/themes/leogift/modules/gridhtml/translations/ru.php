<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gridhtml}leogift>gridhtml_0429f31fd7dc2342b9b0f63d63c1e21d'] = 'Показать простую таблицу HTML';
