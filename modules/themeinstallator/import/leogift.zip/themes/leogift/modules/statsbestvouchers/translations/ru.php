<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_4f29d8c727dcf2022ac241cb96c31083'] = 'Aucun résultat retourné';
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_f5c493141bb4b2508c5938fd9353291a'] = 'Показано %1$s из %2$s';
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_49ee3087348e8d44e1feda1917443987'] = 'Имя';
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Продажи';
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_df25596dc94d556af2f1823725118572'] = 'Всего использовано';
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_b769cee333527b8dc6f3f67882e35a0b'] = 'Лучшие ваучеры';
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_8fc8a29113479bf76f0917c51795ca99'] = 'Список лучших ваучеров';
$_MODULE['<{statsbestvouchers}leogift>statsbestvouchers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
