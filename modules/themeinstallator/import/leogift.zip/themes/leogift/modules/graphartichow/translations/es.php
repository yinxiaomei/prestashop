<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{graphartichow}leogift>graphartichow_6b1e6241446c46f7ab8d28ae83d53e71'] = 'Artichow';
$_MODULE['<{graphartichow}leogift>graphartichow_f2f747178b068abc9cbeac03d93480e6'] = 'Artichow es una biblioteca que permite mostrar simples gráficos cuadro-base usando el PHP y GD.';
