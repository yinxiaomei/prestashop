<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_ecf3e4f8f34a293099620cc25d5b4d93'] = 'Моя учетная запись';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_ecf2ffd31994b3edea4b916011b08bfa'] = 'Отображает блок со ссылками связанными с учетной записью пользователя.';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Моя учетная запись';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_74ecd9234b2a42ca13e775193f391833'] = 'Мои заказы';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_89080f0eedbd5491a93157930f1e45fc'] = 'Мои возвраты покупок';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_9132bc7bac91dd4e1c453d4e96edf219'] = 'Мои кредитные квитанции';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Мои адреса';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_63b1ba91576576e6cf2da6fab7617e58'] = 'Моя личная информация';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_95d2137c196c7f84df5753ed78f18332'] = 'Мои купоны';
$_MODULE['<{blockmyaccount}leogift>blockmyaccount_c87aacf5673fada1108c9f809d354311'] = 'Выйти';
