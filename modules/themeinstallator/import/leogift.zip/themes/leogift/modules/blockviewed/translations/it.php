<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockviewed}leogift>blockviewed_fcb72d5a95d9a713f84425c807bbd667'] = 'Blocco prodotti visti.';
$_MODULE['<{blockviewed}leogift>blockviewed_eaa362292272519b786c2046ab4b68d2'] = 'Aggiunge un blocco che visualizza i prodotti visti recentemente.';
$_MODULE['<{blockviewed}leogift>blockviewed_2e57399079951d84b435700493b8a8c1'] = 'È necessario compilare il campo \"prodotti visualizzati\".';
$_MODULE['<{blockviewed}leogift>blockviewed_73293a024e644165e9bf48f270af63a0'] = 'Numero non valido.';
$_MODULE['<{blockviewed}leogift>blockviewed_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blockviewed}leogift>blockviewed_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockviewed}leogift>blockviewed_e451e6943bb539d1bd804d2ede6474b5'] = 'Prodotti esposti';
$_MODULE['<{blockviewed}leogift>blockviewed_d36bbb6066e3744039d38e580f17a2cc'] = 'Definisci il numero di prodotti esposti in questo blocco.';
$_MODULE['<{blockviewed}leogift>blockviewed_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blockviewed}leogift>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Prodotti visti';
$_MODULE['<{blockviewed}leogift>blockviewed_8f7f4c1ce7a4f933663d10543562b096'] = 'Maggiori informazioni su';
$_MODULE['<{blockviewed}leogift>blockviewed_49fa2426b7903b3d4c89e2c1874d9346'] = 'Maggiori informazioni su';
