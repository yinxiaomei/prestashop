<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockviewed}leogift>blockviewed_fcb72d5a95d9a713f84425c807bbd667'] = 'Bloc produits déjà vus';
$_MODULE['<{blockviewed}leogift>blockviewed_eaa362292272519b786c2046ab4b68d2'] = 'Ajoute un bloc proposant les derniers produits vus par le client.';
$_MODULE['<{blockviewed}leogift>blockviewed_2e57399079951d84b435700493b8a8c1'] = 'Champ \"Produits vus\" obligatoire.';
$_MODULE['<{blockviewed}leogift>blockviewed_73293a024e644165e9bf48f270af63a0'] = 'Nombre non valable.';
$_MODULE['<{blockviewed}leogift>blockviewed_c888438d14855d7d96a2724ee9c306bd'] = 'Configuration mise à jour';
$_MODULE['<{blockviewed}leogift>blockviewed_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuration';
$_MODULE['<{blockviewed}leogift>blockviewed_e451e6943bb539d1bd804d2ede6474b5'] = 'Nombre de produits affichés';
$_MODULE['<{blockviewed}leogift>blockviewed_d36bbb6066e3744039d38e580f17a2cc'] = 'Détermine le nombre de produits affichés dans ce bloc';
$_MODULE['<{blockviewed}leogift>blockviewed_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockviewed}leogift>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Déjà vus';
$_MODULE['<{blockviewed}leogift>blockviewed_8f7f4c1ce7a4f933663d10543562b096'] = 'En savoir plus sur';
$_MODULE['<{blockviewed}leogift>blockviewed_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
