<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'Moje konto - blok';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'Wyświetla blok z linkami relatywnymi dla konta klienta';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Zarządzaj moim kontem klienta';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'Moje konto';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'Moje zamówienia';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'Lista moich zwrotów towaru';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'Moje zwroty towaru';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'Moje noty kredytowe';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Moje adresy';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Zarządzaj moimi informacjami osobistymi';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'Moje informacje osobiste';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'Moje kupony rabatowe';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Wyloguj się';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_057d295c52fbfa6009018983adfcfef3'] = 'Lista moich zamówień';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_84717c9dceaf4edb4d68fb83baad9c5b'] = 'Lista moich zwrotów towaru';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_adb86424a996157ea978c08a665aa552'] = 'Lista moich paragonów';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_ce1f9a653c6297bee14973a2af3c4493'] = 'Lista moich adresów';
$_MODULE['<{blockmyaccountfooter}leogift>blockmyaccountfooter_1f94d078255c7cee3fcfd50c762101e6'] = 'Lista moich voucherów';
