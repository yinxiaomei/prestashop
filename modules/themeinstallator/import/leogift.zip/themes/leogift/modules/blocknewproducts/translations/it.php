<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_f7c34fc4a48bc683445c1e7bbc245508'] = 'Blocco nuovi prodotti';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_d3ee346c7f6560faa13622b6fef26f96'] = 'Visualizza un blocco con i prodotti appena aggiunti.';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_1cd777247f2a6ed79534d4ace72d78ce'] = 'Devi compilare il campo \"prodotti da visualizzare\".';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_73293a024e644165e9bf48f270af63a0'] = 'Numero non valido.';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_9f6f59f676f90cf034870f3bcce96188'] = 'Prodotti da visualizzare.';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_3ea7689283770958661c27c37275b89c'] = 'Imposta il numero di prodotti da visualizzare in questo blocco.';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_41385d2dca40c2a2c7062ed7019a20be'] = 'Visualizza sempre blocco.';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Mostra il blocco anche se nessun prodotto è disponibile.';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Nuovi prodotti';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Maggiori informazioni';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'Tutti i nuovi prodotti';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_18cc24fb12f89c839ab890f8188febe8'] = 'Non permettere nuovi prodotti al momento.';
$_MODULE['<{blocknewproducts}leogift>blocknewproducts_2bc4c1efe10bba9f03fac3c59b4d2ae9'] = 'Nessun nuovo prodotto in questo momento';
