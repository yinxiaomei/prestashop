<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leotempcp}leogift>leotempcp_0db3f5e62ff3a9f6608bf7ec67654b35'] = 'Speichern';
$_MODULE['<{leotempcp}leogift>panel_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
