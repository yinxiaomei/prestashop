<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsdata}leogift>statsdata_a51950bf91ba55cd93a33ce3f8d448c2'] = 'Explotación de datos para las estadísticas';
$_MODULE['<{statsdata}leogift>statsdata_c77dfd683d0d76940e5e04cb24e8bce1'] = 'Este módulo debe estar activado si usted quiere utilizar las estadísticas';
$_MODULE['<{statsdata}leogift>statsdata_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuración actualizada';
$_MODULE['<{statsdata}leogift>statsdata_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{statsdata}leogift>statsdata_1a5b75c4be3c0100c99764b21e844cc8'] = 'Guardar las páginas vistas por cada cliente';
$_MODULE['<{statsdata}leogift>statsdata_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{statsdata}leogift>statsdata_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{statsdata}leogift>statsdata_f3e159134846bd13c0c967f361229233'] = 'Las páginas vistas de los clientes consumen muchos recursos de procesador y espacio en la base de datos.';
$_MODULE['<{statsdata}leogift>statsdata_b368e11d9d23b26f1fb4a1b78584560d'] = 'Guardar las páginas vistas globales';
$_MODULE['<{statsdata}leogift>statsdata_339acfd90b82e91ce9141ec75e4bff24'] = 'Las páginas vistas necesitan menos recursos que el detalle por cliente, pero siguen necesitando bastantes.';
$_MODULE['<{statsdata}leogift>statsdata_c0e4406117ba4c29c4d66e3069ebf3d3'] = 'Detección de plug-ins';
$_MODULE['<{statsdata}leogift>statsdata_7a6cf506bde903b2b30c0a4cbcfa0291'] = 'La detección de los plug-ins carga un archivo javascript de 20 ko suplementario para los nuevos visitantes.';
$_MODULE['<{statsdata}leogift>statsdata_06933067aafd48425d67bcb01bba5cb6'] = 'Actualizar';
