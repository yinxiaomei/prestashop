<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockadvertising}prestashop>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Title';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_ad3d06d03d94223fa652babc913de686'] = 'Validate';
