<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksocial}prestashop>blocksocial_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'The block configuration has been updated.';
