<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_461900b74731e07320ca79366df3e809'] = 'Image';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_630f6dc397fe74e52d5189e2c80f282b'] = 'Back to list';
$_MODULE['<{blockreinsurance}prestashop>blockreinsurance_ef61fb324d729c341ea8ab9901e23566'] = 'Add new';
