<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockspecials}prestashop>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Your settings have been updated.';
$_MODULE['<{blockspecials}prestashop>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockspecials}prestashop>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{blockspecials}prestashop>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{blockspecials}prestashop>blockspecials_a8a670d89a6d2f3fa59942fc591011ef'] = 'Show the block even if no products are available.';
$_MODULE['<{blockspecials}prestashop>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockspecials}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'No product specials are available at this time.';
