<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{followup}prestashop>followup_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{followup}prestashop>followup_2faec1f9f8cc7f8f40d521c4dd574f49'] = 'Enable';
$_MODULE['<{followup}prestashop>followup_b30690be173bcd4a83df0cd68f89a385'] = 'Discount amount';
$_MODULE['<{followup}prestashop>followup_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{followup}prestashop>followup_c33e404a441c6ba9648f88af3c68a1ca'] = 'Statistics';
$_MODULE['<{followup}prestashop>followup_44749712dbec183e983dcd78a7736c41'] = 'Date';
