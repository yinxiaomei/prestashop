<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcontact}prestashop>blockcontact_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'The block configuration has been updated.';
$_MODULE['<{blockcontact}prestashop>blockcontact_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{blockcontact}prestashop>blockcontact_673ae02fffb72f0fe68a66f096a01347'] = 'Phone';
$_MODULE['<{blockcontact}prestashop>blockcontact_8b1f7be76996ad6911a17592b9804e1b'] = 'Our support hotline is available 24/7.';
$_MODULE['<{blockcontact}prestashop>blockcontact_e6d0e56415c30a59658fb34ef5d7be35'] = 'Contact our expert support team!';
