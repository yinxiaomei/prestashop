<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_a85eba4c6c699122b2bb1387ea4813ad'] = 'Cart';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_deb10517653c255364175796ace3553f'] = 'Product';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_068f80c7519d0528fb08e82137a72131'] = 'Products';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_83218ac34c1834c26781fe4bde918ee4'] = 'Welcome';
$_MODULE['<{blockuserinfo}prestashop>blockuserinfo_99dea78007133396a7b8ed70578ac6ae'] = 'Login';
