<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockpaymentlogo}prestashop>blockpaymentlogo_f1206f9fadc5ce41694f69129aecac26'] = 'Configure';
