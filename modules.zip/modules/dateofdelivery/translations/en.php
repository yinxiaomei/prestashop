<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_7ccf58c950043c9fbfed668df13ce608'] = 'The settings have been updated.';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_06df33001c1d7187fdd81ea1f5b277aa'] = 'Actions';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_7dce122004969d56ae2e0245cb754d35'] = 'Edit';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_f2a6c498fb90ee345d997f888fce3b18'] = 'Delete';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_4dab36ac83853282fc0d7bae20c19e90'] = 'More options';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_104f1a7d59077b514d4105fcee0e42ff'] = 'Date format';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_f8617a92ba0a0a4eabee724eab7c9f48'] = 'Carrier';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_961f2247a2070bedff9f9cd8d64e2650'] = 'Choose';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_9d1a0949c39e66a0cd65240bc0ac9177'] = 'Sunday';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_6f8522e0610541f1ef215a22ffa66ff6'] = 'Monday';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_5792315f09a5d54fb7e3d066672b507f'] = 'Tuesday';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_796c163589f295373e171842f37265d5'] = 'Wednesday';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_78ae6f0cd191d25147e252dc54768238'] = 'Thursday';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_c33b138a163847cdb6caeeb7c9a126b4'] = 'Friday';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_8b7051187b9191cdcdae6ed5a10e5adc'] = 'Saturday';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_86f5978d9b80124f509bdb71786e929e'] = 'January';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_659e59f062c75f81259d22786d6c44aa'] = 'February';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_fa3e5edac607a88d8fd7ecb9d6d67424'] = 'March';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_3fcf026bbfffb63fb24b8de9d0446949'] = 'April';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_195fbb57ffe7449796d23466085ce6d8'] = 'May';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_688937ccaf2a2b0c45a1c9bbba09698d'] = 'June';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_1b539f6f34e8503c97f6d3421346b63c'] = 'July';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_41ba70891fb6f39327d8ccb9b1dafb84'] = 'August';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_cc5d90569e1c8313c2b1c2aab1401174'] = 'September';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_eca60ae8611369fe28a02e2ab8c5d12e'] = 'October';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_7e823b37564da492ca1629b4732289a8'] = 'November';
$_MODULE['<{dateofdelivery}prestashop>dateofdelivery_82331503174acbae012b2004f6431fa5'] = 'December';
