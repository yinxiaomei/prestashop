<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{editorial}prestashop>editorial_5db205c79efd29b0e4f52d0c1ff45d20'] = 'Save';
$_MODULE['<{editorial}prestashop>editorial_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
