<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-footer_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'Contact';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'Sitemap';
$_MODULE['<{blockpermanentlinks}prestashop>blockpermanentlinks_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contact';
